<?php
/**
 * Common Plugin Functions
 * 
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/core
 * @since 1.0
 */
if ( ! defined( 'WPINC' ) ) { die; }


global $wc_zipcode_val_db_settins_values, $wc_zipcode_val_vars;
$wc_zipcode_val_db_settins_values = array();
$wc_zipcode_val_vars = array();

add_action('wc_zipcode_val_before_addons_load','wc_zipcode_val_get_settings_from_db',1);

if(!function_exists('wc_zipcode_val_vars')){
    function wc_zipcode_val_vars($key,$values = false){
        global $wc_zipcode_val_vars;
        if(isset($wc_zipcode_val_vars[$key])){ 
            return $wc_zipcode_val_vars[$key]; 
        }
        return $values;
    }
}
if(!function_exists('wc_zipcode_val_add_vars')){
    function wc_zipcode_val_add_vars($key,$values){
        global $wc_zipcode_val_vars;
        if(! isset($wc_zipcode_val_vars[$key])){ 
            $wc_zipcode_val_vars[$key] = $values; 
            return true; 
        }
        return false;
    }
}
if(!function_exists('wc_zipcode_val_remove_vars')){
    function wc_zipcode_val_remove_vars($key){
        global $wc_zipcode_val_vars;
        if(isset($wc_zipcode_val_vars[$key])){ 
            unset($wc_zipcode_val_vars[$key]);
            return true; 
        }
        return false;
    }
}


if(!function_exists('wc_zipcode_val_option')){
	function wc_zipcode_val_option($key = '',$default = false){
		global $wc_zipcode_val_db_settins_values;
		if($key == ''){return $wc_zipcode_val_db_settins_values;}
		if(isset($wc_zipcode_val_db_settins_values[WC_ZIP_V_DB.$key])){
			return $wc_zipcode_val_db_settins_values[WC_ZIP_V_DB.$key];
		} 
		
		return $default;
	}
}

if(!function_exists('wc_zipcode_val_get_settings_from_db')){
	/**
	 * Retrives All Plugin Options From DB
	 */
	function wc_zipcode_val_get_settings_from_db(){
		global $wc_zipcode_val_db_settins_values;
		$section = array();
		$section = apply_filters('wc_zipcode_val_settings_section',$section); 
		$values = array();
		foreach($section as $settings){
			foreach($settings as $set){
				$db_val = get_option(WC_ZIP_V_DB.$set['id']);
				if(is_array($db_val)){ unset($db_val['section_id']); $values = array_merge($db_val,$values); }
			}
		}        
		$wc_zipcode_val_db_settins_values = $values;
	}
}

if(!function_exists('wc_zipcode_val_is_request')){
    /**
	 * What type of request is this?
	 * string $type ajax, frontend or admin
	 * @return bool
	 */
    function wc_zipcode_val_is_request( $type ) {
        switch ( $type ) {
            case 'admin' :
                return is_admin();
            case 'ajax' :
                return defined( 'DOING_AJAX' );
            case 'cron' :
                return defined( 'DOING_CRON' );
            case 'frontend' :
                return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' );
        }
    }
}

if(!function_exists('wc_zipcode_val_current_screen')){
    /**
     * Gets Current Screen ID from wordpress
     * @return string [Current Screen ID]
     */
    function wc_zipcode_val_current_screen(){
       $screen =  get_current_screen();
       return $screen->id;
    }
}


if(!function_exists('wc_zipcode_val_is_screen')){
    function wc_zipcode_val_is_screen($check_screen = '',$current_screen = ''){
        if(empty($check_screen)) {$check_screen = wc_zipcode_val_get_screen_ids(); }
        if(empty($current_screen)) {$current_screen = wc_zipcode_val_current_screen(); }
        
        if(is_array($check_screen)){
            if(in_array($current_screen , $check_screen)){
                return true;
            }
        }
        
        if(is_string($check_screen)){
            if($check_screen == $current_screen){
                return true;
            }
        }
        return false;
    }
}


if(!function_exists('wc_zipcode_val_get_screen_ids')){
    /**
     * Returns Predefined Screen IDS
     * @return [Array] 
     */
    function wc_zipcode_val_get_screen_ids(){
        $screen_ids = array();
        $screen_ids[] = 'woocommerce_page_wooCommerce-area-base-shipping-rate-settings';
        $screen_ids[] = wc_zipcode_val_vars('settings_page');
        return $screen_ids;
    }
}

if(!function_exists('wc_zipcode_val_dependency_message')){
	function wc_zipcode_val_dependency_message(){
		$text = __( WC_ZIP_V_NAME . ' requires <b> WooCommerce </b> To Be Installed..  <br/> <i>Plugin Deactivated</i> ', WC_ZIP_V_TXT);
		return $text;
	}
}

if(!function_exists('wc_zipcode_val_get_template')){
	function wc_zipcode_val_get_template($name,$args = array(),$template_base = '',$remote_template = ''){
        if(empty($template_base)){$template_base = WC_ZIP_V_PATH.'/templates/';}
        if(empty($remote_template)){$remote_template = 'woocommerce/';}
		wc_get_template( $name, $args ,$remote_template,  $template_base);
	}
}

if(!function_exists('wc_zipcode_val_settings_products_json')){
    function wc_zipcode_val_settings_products_json($ids){
        $json_ids    = array();
        if(!empty($ids)){
            $ids = explode(',',$ids);
            foreach ( $ids as $product_id ) {
                $product = wc_get_product( $product_id );
                $json_ids[ $product_id ] = wp_kses_post( $product->get_formatted_name() );
            }   
        }
        return $json_ids;
    }
}

if(!function_exists('wc_zipcode_val_settings_get_categories')){
    function wc_zipcode_val_settings_get_categories($tax='product_cat'){
        $args = array();
        $args['hide_empty'] = false;
        $args['number'] = 0; 
        $args['pad_counts'] = true; 
        $args['update_term_meta_cache'] = false;
        $terms = get_terms($tax,$args);
        $output = array();
        
        foreach($terms as $term){
            $output[$term->term_id] = $term->name .' ('.$term->count.') ';
        }
        
        return $output; 
    }
}

if(!function_exists('wc_zipcode_val_settings_page_link')){
    function wc_zipcode_val_settings_page_link($tab = '',$section = ''){
        $settings_url = admin_url('admin.php?page='.WC_ZIP_V_SLUG.'-settings');
        if(!empty($tab)){$settings_url .= '&tab='.$tab;}
        if(!empty($section)){$settings_url .= '#'.$section;}
        return $settings_url;
    }   
}

if(!function_exists('wc_zipcode_val_get_settings_sample')){
	/**
	 * Retunrs the sample array of the settings framework
	 * @param [string] [$type = 'page' | 'section' | 'field'] [[Description]]
	 */
	function wc_zipcode_val_get_settings_sample($type = 'page'){
		$return = array();
		
		if($type == 'page'){
			$return = array( 
				'id'=>'settings_general', 
				'slug'=>'general', 
				'title'=>__('General',WC_ZIP_V_TXT),
				'multiform' => 'false / true',
				'submit' => array( 
					'text' => __('Save Changes',WC_ZIP_V_TXT), 
					'type' => 'primary / secondary / delete', 
					'name' => 'submit'
				)
			);
			
		} else if($type == 'section'){
			$return['page_id'][] = array(
				'id'=>'general',
				'title'=>'general', 
				'desc' => 'general',
				'submit' => array(
					'text' => __('Save Changes',WC_ZIP_V_TXT), 
					'type' => 'primary / secondary / delete', 
					'name' => 'submit'
				)
			);
		} else if($type == 'field'){
			$return['page_id']['section_id'][] = array(
				'id' => '',
				'type' => 'text, textarea, checkbox, multicheckbox, radio, select, field_row, extra',
				'label' => '',
				'options' => 'Only required for type radio, select, multicheckbox [KEY Value Pair]',
				'desc' => '',
				'size' => '',
				'default' => '',
				'attr' => "Key Value Pair",
				'before' => 'Content before the field label',
				'after' => 'Content after the field label',
				'content' => 'Content used for type extra' ,
				'text_type' => "Set the type for text input field (e.g. 'hidden' )",
			);
		}
	}
}

if(!function_exists('wc_zipcode_val_check_active_addon')){
	function wc_zipcode_val_check_active_addon($slug){
		$addons = wc_zipcode_val_get_active_addons();
		if(in_array($slug,$addons)){ return true; }
		return false;
	}
}

if(!function_exists('wc_zipcode_val_get_active_addons')){
	/**
	 * Returns Active Addons List
	 * @return [[Type]] [[Description]]
	 */
	function wc_zipcode_val_get_active_addons(){
		$addons = get_option(WC_ZIP_V_DB.'active_addons',array()); 
		return $addons;
	}
}

if(!function_exists('wc_zipcode_val_update_active_addons')){
	/**
	 * Returns Active Addons List
	 * @return [[Type]] [[Description]]
	 */
	function wc_zipcode_val_update_active_addons($addons){
		update_option(WC_ZIP_V_DB.'active_addons',$addons); 
		return true;
	}
}

if(!function_exists('wc_zipcode_val_activate_addon')){
	function wc_zipcode_val_activate_addon($slug){
		$active_list = wc_zipcode_val_get_active_addons();
		if(!in_array($slug,$active_list)){
			$active_list[] = $slug;
			wc_zipcode_val_update_active_addons($active_list);
			return true;
		}
		return false;
	}
}

if(!function_exists('wc_zipcode_val_deactivate_addon')){
	function wc_zipcode_val_deactivate_addon($slug){
		$active_list = wc_zipcode_val_get_active_addons();
		if(in_array($slug,$active_list)){
			$key = array_search($slug, $active_list);
			unset($active_list[$key]);
			wc_zipcode_val_update_active_addons($active_list);
			return true;
		}
		return false;
	}
}

if(!function_exists('wc_zipcode_val_admin_notice')){
    function wc_zipcode_val_admin_notice($msg , $type = 'updated'){
        $notice = ' <div class="'.$type.' settings-error notice is-dismissible" id="setting-error-settings_updated"> 
<p>'.$msg.'</p><button class="notice-dismiss" type="button"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
        return $notice;
    }
}

if(!function_exists('wc_zipcode_val_remove_notice')){
    function wc_zipcode_val_remove_notice($id){
        woocommerce_zipcode_validation_Admin_Notices::getInstance()->deleteNotice($id);
        return true;
    }
}

if(!function_exists('wc_zipcode_val_notice')){
    function wc_zipcode_val_notice( $message, $type = 'update',$args = array()) {
        $notice = '';
        $defaults = array('times' => 1,'screen' => array(),'users' => array(), 'wraper' => true,'id'=>'');    
        $args = wp_parse_args( $args, $defaults );
        extract($args);
        
        if($type == 'error'){
            $notice = new woocommerce_zipcode_validation_Admin_Error_Notice($message,$id,$times, $screen, $users);
        }
        
        if($type == 'update'){
            $notice = new woocommerce_zipcode_validation_Admin_Updated_Notice($message,$id,$times, $screen, $users);
        }
        
        if($type == 'upgrade'){
            $notice = new woocommerce_zipcode_validation_Admin_UpdateNag_Notice($message,$id,$times, $screen, $users);
        } 
        
        $msgID = $notice->getId();
        $message = str_replace('$msgID$',$msgID,$message);
        $notice->setContent($message);
        $notice->setWrapper($wraper);
        woocommerce_zipcode_validation_Admin_Notices::getInstance()->addNotice($notice);
    }
}

if(!function_exists('wc_zipcode_val_admin_error')){
    function wc_zipcode_val_admin_error( $message,$times = 1, $id, $screen = array(),$args = array()) {
        $args['id'] = $id;
        $args['times'] = $times;
        $args['screen'] = $screen;
        wc_zipcode_val_notice($message,'error',$args);
    }
}

if(!function_exists('wc_zipcode_val_admin_update')){
    function wc_zipcode_val_admin_update( $message,$times = 1, $id, $screen = array(),$args = array()) {
        $args['id'] = $id;
        $args['times'] = $times;
        $args['screen'] = $screen;
        wc_zipcode_val_notice($message,'update',$args);
    }
}

if(!function_exists('wc_zipcode_val_admin_upgrade')){
    function wc_zipcode_val_admin_upgrade( $message,$times = 1, $id, $screen = array(),$args = array()) {
        $args['id'] = $id;
        $args['times'] = $times;
        $args['screen'] = $screen;
        wc_zipcode_val_notice($message,'upgrade',$args);
    }
}


if(!function_exists('wc_zipcode_val_remove_link')){
    function wc_zipcode_val_remove_link($attributes = '',$msgID = '$msgID$', $text = 'Remove Notice') {
        if(!empty($msgID)){
            $removeKey = WC_ZIP_V_DB.'MSG';
            $url = admin_url().'?'.$removeKey.'='.$msgID ;
            //$url = wp_nonce_url($url, 'WCQDREMOVEMSG');
            $url = urldecode($url);
            $tag = '<a '.$attributes.' href="'.$url.'">'.__($text,WC_PBP_TXT).'</a>';
            return $tag;
        }
    }
}

if(!function_exists('wc_zipcode_val_get_ajax_overlay')){
	/**
	 * Prints WC PBP Ajax Loading Code
	 */
	function wc_zipcode_val_get_ajax_overlay($echo = true){
		$return = '<div class="wc_zipcode_val_ajax_overlay">
		<div class="wc_zipcode_val_sk-folding-cube">
		<div class="wc_zipcode_val_sk-cube1 wc_zipcode_val_sk-cube"></div>
		<div class="wc_zipcode_val_sk-cube2 wc_zipcode_val_sk-cube"></div>
		<div class="wc_zipcode_val_sk-cube4 wc_zipcode_val_sk-cube"></div>
		<div class="wc_zipcode_val_sk-cube3 wc_zipcode_val_sk-cube"></div>
		</div>
		</div>';
		if($echo){echo $return;}
		else{return $return;}
	}
}







if (!function_exists('wc_zipcode_form_field')) {
	/**
	 * Outputs a checkout/address form field.
	 *
	 * @subpackage	Forms
	 * @param string $key
	 * @param mixed $args
	 * @param string $value (default: null)
	 * @todo This function needs to be broken up in smaller pieces
	 */
	function wc_zipcode_form_field( $key, $args, $value = null ) {
		$defaults = array(
			'type'              => 'text',
			'label'             => '',
			'description'       => '',
			'placeholder'       => '',
            'name'              => $key,
			'maxlength'         => false,
			'required'          => false,
			'autocomplete'      => false,
			'id'                => $key,
			'class'             => array(),
            'only_field' => false,
			'label_class'       => array(),
			'input_class'       => array(),
			'return'            => false,
			'options'           => array(),
			'custom_attributes' => array(),
			'validate'          => array(),
			'default'           => '',
            'value'             => null,
		);
        
        
        
		$args = wp_parse_args( $args, $defaults );
        if(is_null($value)){$value = $args['value'];}
		$args = apply_filters( 'wc_zipcode_validation_form_field_args', $args, $key, $value );
        $key = $args['name'];
            
		if ( $args['required'] ) {
			$args['class'][] = 'validate-required';
			$required = ' <abbr class="required" title="' . esc_attr__( 'required', WC_ZIP_V_TXT ) . '">*</abbr>';
		} else {
			$required = '';
		}
        
		$args['maxlength'] = ( $args['maxlength'] ) ? 'maxlength="' . absint( $args['maxlength'] ) . '"' : '';
		$args['autocomplete'] = ( $args['autocomplete'] ) ? 'autocomplete="' . esc_attr( $args['autocomplete'] ) . '"' : '';
		if ( is_string( $args['label_class'] ) ) {
			$args['label_class'] = array( $args['label_class'] );
		}
		if ( is_null( $value ) ) {
			$value = $args['default'];
		}
        
		$custom_attributes = array();
		if ( ! empty( $args['custom_attributes'] ) && is_array( $args['custom_attributes'] ) ) {
			foreach ( $args['custom_attributes'] as $attribute => $attribute_value ) {
				$custom_attributes[] = esc_attr( $attribute ) . '="' . $attribute_value . '"';
			}
		}
		if ( ! empty( $args['validate'] ) ) {
			foreach( $args['validate'] as $validate ) {
				$args['class'][] = 'validate-' . $validate;
			}
		}
		$field = '';
		$label_id = $args['id'];
		$field_container = '<div class="%1$s" id="%2$s">%3$s</div>';
		switch ( $args['type'] ) {
            case 'country' :

				$countries = 'shipping_country' === $key ? WC()->countries->get_shipping_countries() : WC()->countries->get_allowed_countries();

				if ( 1 === sizeof( $countries ) ) {

					$field .= '<strong>' . current( array_values( $countries ) ) . '</strong>';

					$field .= '<input type="hidden" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="' . current( array_keys($countries ) ) . '" ' . implode( ' ', $custom_attributes ) . ' class="country_to_state" />';

				} else {

					$field = '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" ' . $args['autocomplete'] . ' class="country_to_state country_select ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" ' . implode( ' ', $custom_attributes ) . '>'
							. '<option value="">'.__( 'Select a country&hellip;', 'woocommerce' ) .'</option>';

					foreach ( $countries as $ckey => $cvalue ) {
						$field .= '<option value="' . esc_attr( $ckey ) . '" '. selected( $value, $ckey, false ) . '>'. __( $cvalue, 'woocommerce' ) .'</option>';
					}

					$field .= '</select>';

                     if(isset($args['force_empty_country'])){
                     $field .= '';
                     } else {
                    $field .= '<noscript><input type="submit" name="woocommerce_checkout_update_totals" value="' . esc_attr__( 'Update country', 'woocommerce' ) . '" /></noscript>';
                }
					

				}

				break;
			case 'state' :

				/* Get Country */
				
                
				
                if(isset($args['force_empty_state'])){
                    $current_cc = null;
                } else {
                    $country_key = 'billing_state' === $key ? 'billing_country' : 'shipping_country';
                    $current_cc  = WC()->checkout->get_value( $country_key );
                }
                
				$states      = WC()->countries->get_states( $current_cc );
                $countries = 'shipping_country' === $key ? WC()->countries->get_shipping_countries() : WC()->countries->get_allowed_countries();
                
				if ( is_array( $states ) && empty( $states ) ) {

					$field_container = '<p class="form-row %1$s" id="%2$s" style="display: none">%3$s</p>';

					$field .= '<input type="hidden" class="hidden" name="' . esc_attr( $key )  . '" id="' . esc_attr( $args['id'] ) . '" value="" ' . implode( ' ', $custom_attributes ) . ' placeholder="' . esc_attr( $args['placeholder'] ) . '" />';

				} elseif ( is_array( $states ) ) {

					$field .= '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="state_select ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . $args['autocomplete'] . '>
						<option value="">'.__( 'Select a state&hellip;', 'woocommerce' ) .'</option>';

					foreach ( $states as $ckey => $cvalue ) {
                        //$countries
                        if(!empty($cvalue)){
                            if(is_array($cvalue)){
                                $field .= '<optgroup label="'.$countries[$ckey].'"> ';
                                    foreach($cvalue as $id => $v){
                                        $field .= '<option value="'.esc_attr( $id).'" '.selected( $value, $id, false ) .'>'.__( $v, 'woocommerce' ) .'</option>';
                                    }
                                $field .= '</optgroup> ';
                            } else {
                                $field .= '<option value="' . esc_attr( $ckey ) . '" '.selected( $value, $ckey, false ) .'>'.__( $cvalue, 'woocommerce' ) .'</option>';
                            }
                        
                        
                        }
                        
                        
                        
                        
                        
						
					}

					$field .= '</select>';

				} else {

					$field .= '<input type="text" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" value="' . esc_attr( $value ) . '"  placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . $args['autocomplete'] . ' name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" ' . implode( ' ', $custom_attributes ) . ' />';

				}

				break;
			case 'textarea' :
				$field .= '<textarea name="' . esc_attr( $key ) . '" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . $args['maxlength'] . ' ' . $args['autocomplete'] . ' ' . ( empty( $args['custom_attributes']['rows'] ) ? ' rows="2"' : '' ) . ( empty( $args['custom_attributes']['cols'] ) ? ' cols="5"' : '' ) . implode( ' ', $custom_attributes ) . '>'. esc_textarea( $value  ) .'</textarea>';
				break;
                
			case 'checkbox' :
				$field = '<label class="checkbox ' . implode( ' ', $args['label_class'] ) .'" ' . implode( ' ', $custom_attributes ) . '>
						<input type="' . esc_attr( $args['type'] ) . '" class="input-checkbox ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="1" '.checked( $value, 1, false ) .' /> '
						 . $args['label'] . $required . '</label>';
				break;
                
			case 'password' :
			case 'text' :
			case 'email' :
            case 'hidden' :
			case 'tel' :
			case 'number' :
				$field .= '<input type="' . esc_attr( $args['type'] ) . '" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . $args['maxlength'] . ' ' . $args['autocomplete'] . ' value="' . esc_attr( $value ) . '" ' . implode( ' ', $custom_attributes ) . ' />';
				break;
                
			case 'select' :
				$options = $field = '';
				if ( ! empty( $args['options'] ) ) {
					foreach ( $args['options'] as $option_key => $option_text ) {
                        
                        if(is_array($option_text)){
                            $options .= '<optgroup label="'.$option_key.'"> ';
                            foreach($option_text as $opk => $opv){
                                if ( '' === $opk ) {
                                    if ( empty( $args['placeholder'] ) ) {
                                        $args['placeholder'] = $opk ? $opk : __( 'Choose an option', WC_ZIP_V_TXT );
                                    }
                                    $custom_attributes[] = 'data-allow_clear="true"';
                                }       
                                
                                $options .= '<option value="'.esc_attr( $opk ).'"'.selected($value,$opk,false).'>'.esc_attr($opv).'</option>';
                            }
                            $options .= '</optgroup> ';
                        } else {
                            if ( '' === $option_key ) {
                                if ( empty( $args['placeholder'] ) ) {
                                    $args['placeholder'] = $option_text ? $option_text : __( 'Choose an option', WC_ZIP_V_TXT );
                                }
                                $custom_attributes[] = 'data-allow_clear="true"';
                            }
                            
                            if(is_array($value)){
                                $selected = in_array($option_key,$value) ? 'selected' : '';
                            } else {
                                $selected = selected( $value, $option_key, false );
                            }
                            $options .= '<option value="' . esc_attr( $option_key ) . '" '. $selected . '>' . esc_attr( $option_text ) .'</option>';
                        }
					}
					$field .= '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="select '. esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . $args['autocomplete'] . '>
							' . $options . '
						</select>';
				}
				break;
                
			case 'radio' :
				$label_id = current( array_keys( $args['options'] ) );
				if ( ! empty( $args['options'] ) ) {
					foreach ( $args['options'] as $option_key => $option_text ) {
						$field .= '<div class="input-radio-container" > <input type="radio" class="input-radio ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" value="' . esc_attr( $option_key ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '"' . checked( $value, $option_key, false ) . ' />';
						$field .= '<label for="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '" class="radio ' . implode( ' ', $args['label_class'] ) .'">' . $option_text . '</label> </div>';
					}
				}
				break;
                
            case 'checkbox_group' :
				$label_id = current( array_keys( $args['options'] ) );
				if ( ! empty( $args['options'] ) ) {
					foreach ( $args['options'] as $option_key => $option_text ) {
						$field .= '<div class="input-checkbox-container" > <input type="checkbox" class="input-checkbox ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" value="' . esc_attr( $option_key ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '"' . checked( $value, $option_key, false ) . ' />';
						$field .= '<label for="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '" class="checkbox ' . implode( ' ', $args['label_class'] ) .'">' . $option_text . '</label> </div>';
					}
				}
				break;
                
            case 'submit' :
            case 'button' :
            case 'reset' :
                $value = empty($value) ? $value = esc_attr( $args['label']) : $value;
                $args['label'] = '';
                $field .= '<button type="' . esc_attr( $args['type'] ) . '" class="button button-' . esc_attr( $args['type'] ) . '  ' . esc_attr( $args['type'] ) . ' ' . esc_attr( implode( ' ', $args['input_class'] ) ) .'" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" '.implode( ' ', $custom_attributes ).'>' . esc_attr( $value ) . '</button> ';
                break;            
		}
        
        
        if ( ! empty( $field ) ) {
            if($args['only_field']){
                return $field;
            }
			$field_html = '';
			if ( $args['label'] && 'checkbox' != $args['type'] ) {
				$field_html .= '<div class="field-label"> <label for="' . esc_attr( $label_id ) . '" class="' . esc_attr( implode( ' ', $args['label_class'] ) ) .'">' . $args['label'] . $required . '</label></div>';
			}
			$field_html .= $field;
			if ( $args['description'] ) {
				$field_html .= '<span class="description">' . esc_html( $args['description'] ) . '</span>';
			}
			$container_class = 'form-row ' . esc_attr( implode( ' ', $args['class'] ) );
			$container_id = esc_attr( $args['id'] ) . '_field';
			$after = ! empty( $args['clear'] ) ? '<div class="clear"></div>' : '';
			$field = sprintf( $field_container, $container_class, $container_id, $field_html ) . $after;
		}
		$field = apply_filters( 'wc_zipcode_validation_form_field_' . $args['type'], $field, $key, $args, $value );
		if ( $args['return'] ) {
			return $field;
		} else {
			echo $field;
		}
	}
}


if(!function_exists('wc_zipcode_get_service_methods')){
    function wc_zipcode_get_service_methods(){
        $return = array('prepaid' => __("Pre-Paid",WC_ZIP_V_TXT),'cod' => __('Cash On Delivery',WC_ZIP_V_TXT));
        $return = apply_filters('wc_zipcode_service_methods',$return);
        return $return;
        //return woocommerce_zipcode_validation()->query()->get_meta($affiliate_id, $meta_key, $single);
    }
}

if(!function_exists('wc_get_zipcode')){
    function wc_get_zipcode($affiliate_id = 0, $meta_key = '', $single = true){
        return woocommerce_zipcode_validation()->query()->get_meta($affiliate_id, $meta_key, $single);
    }
}
if(!function_exists('wc_add_zipcode')){
    function wc_add_zipcode($affiliate_id = 0, $meta_key = '', $meta_value = '', $unique = false){
        return woocommerce_zipcode_validation()->query()->add_meta($affiliate_id, $meta_key, $meta_value, $unique );
    }
}
if(!function_exists('wc_update_zipcode')){
    function wc_update_zipcode($affiliate_id = 0, $meta_key = '', $meta_value = '', $prev_value = ''){
        return woocommerce_zipcode_validation()->query()->update_meta($affiliate_id, $meta_key, $meta_value, $prev_value);
    }
}
if(!function_exists('wc_delete_zipcode')){
    function wc_delete_zipcode($affiliate_id = 0, $meta_key = '', $meta_value = ''){
        return woocommerce_zipcode_validation()->query()->delete_meta($affiliate_id, $meta_key, $meta_value);
    }
}
























if(!function_exists('wc_zipcode_get_all_payment_methods')){
    function wc_zipcode_get_all_payment_methods() {
        global $woocommerce;
        $payment_methods_loaded = $woocommerce->payment_gateways->payment_gateways;

        $payment_methods = array();
        foreach($payment_methods_loaded as $method){
            if ($method->enabled == 'yes') {
                if($method->title == 'Mollie' && $this->has_mollie()) {
                    $instance = $GLOBALS['wc_mollie'];
                    $gateway = $instance->get_gateway();
                    $methods = $gateway->get_methods();
                    foreach($methods as $method) {
                        $method->id = 'mollie_' . $method->id;
                        $method->description = $method->description . ' (Mollie)';
                        $payment_methods[] = $method;					
                    }
                } else {
                    $payment_methods[] = $method;	
                }
            }
        }
        return $payment_methods;
    }
}


if(!function_exists('wc_zipcode_get_all_payment_method_slugs')){
    function wc_zipcode_get_all_payment_method_slugs($forsettings = false) {
        $payment_methods = wc_zipcode_get_all_payment_methods();    
        $slugs = array();
        foreach($payment_methods as $method){
            if($forsettings){
                $slugs[$method->id] = $method->title;
            } else {
                $slugs[] = $method->id;
            }
            
        }
        return $slugs;
    }
}

if(!function_exists('wc_zipcode_get_all_shipping_method_slugs')){
    function wc_zipcode_get_all_shipping_method_slugs($forsettings = false) {
        $payment_methods = wc_zipcode_get_all_shipping_methods();
        
        $slugs = array();
        foreach($payment_methods as $method){
            if($forsettings){
                $slugs[$method->id] = $method->method_title;
            } else {
                $slugs[] = $method->id;
            }
            
        }
        return $slugs;
    }
}

if(!function_exists('wc_zipcode_get_all_shipping_methods')){
    function wc_zipcode_get_all_shipping_methods() {
        global $woocommerce;
        if(sizeof($woocommerce->shipping->shipping_methods) > 0){
            $shipping_methods = $woocommerce->shipping->shipping_methods;
        } else {
            $shipping_methods = $woocommerce->shipping->load_shipping_methods();
        }

        
        return $shipping_methods;
    }
}















if(!function_exists('wc_zipcode_generate_tabs')){
    function wc_zipcode_generate_tabs($tabs,$content,$args = array()){
        $default_args = array(
            'show_image' => true,
            'tab_style' => 'left', // 'default', 'box' or 'left'. Optional
            'tab_wrapper' => true,
            'default_icon' => 'dashicons dashicons-admin-users',
        );
        
        
        $args = wp_parse_args($args,$default_args);
        $wraper_start = '<div class="wczipcode-tabs  wczipcode-tabs-'.$args['tab_style'].'">';
        $wraper_end = '</div>';
        
        $tabs_code = '<ul class="wczipcode-tab-nav">';
        $i = 0;
        foreach ( $tabs as $key => $tab_data ) {
            if ( is_string( $tab_data ) ) { $tab_data = array( 'title' => $tab_data ); }
            $tab_data = wp_parse_args( $tab_data, array( 'icon'  => '', 'title' => '','show_status' =>  true));
            if ( filter_var( $tab_data['icon'], FILTER_VALIDATE_URL ) ) {
                $icon = '<img src="' . $tab_data['icon'] . '">';
            } else {
                if ( false !== strpos( $tab_data['icon'], 'dashicons' ) ) {
                    $tab_data['icon'] .= ' dashicons';
                } else {
                    if(!empty($args['default_icon'])){
                        $tab_data['icon'] = $args['default_icon'];
                    }
                }
                $tab_data['icon'] = array_filter( array_map( 'trim', explode( ' ', $tab_data['icon'] ) ) );
                $tab_data['icon'] = implode( ' ', array_unique( $tab_data['icon'] ) );
                $icon = $tab_data['icon'] ? '<i class="' . $tab_data['icon'] . '"></i>' : '';
            }
            
            $show_status = 'no';
            $status_tag = '';
            if($tab_data['show_status']){
                $show_status = 'yes';
                $status_tag = '<i class="wc-rbp-tab-status"></i>';
            }

            $class = "wczipcode-tab-$key";
            if ( ! $i ){$class .= ' wczipcode-tab-active';}
            $tabs_code .= sprintf('<li data-status="%s" class="%s" data-panel="%s"><a href="#">%s%s%s</a></li>', $show_status,$class, $key, $icon, $tab_data['title'],$status_tag);
            $i ++;
        }
        
        $tabs_code .= '</ul>';
        
        
        $content_data  = '<div class="wczipcode-tab-panels">';
		foreach ($content as $id  => $data ) {
			$content_data .= '<div class="wczipcode-tab-panel wczipcode-tab-panel-' . $id . '">';
			$content_data .= $data;
			$content_data .= '</div>';
		}
        
		$content_data .= '</div>';
        
        $final = $wraper_start .$tabs_code .$content_data .$wraper_end;
        return $final;
    }
}




/**
 * Change the checkout city field to a dropdown field.
 */
function wc_change_city_to_dropdown( $fields ) {

    global $wpdb;
        $res = $wpdb->get_results("SELECT DISTINCT wczipcode_id,meta_value FROM `{$wpdb->prefix}wc_zipcode_meta` WHERE meta_key = 'zipcode_data'",ARRAY_A);
    
    $cityArray = array();
    $cityArray[""] = "Select City";
    foreach ($res as $value) {
       $value = unserialize($value["meta_value"]);
    if ( in_array(strtolower($value['city']), $cityArray) ) {
        continue;
    }
    $cityArray[strtolower($value['city'])] = strtolower($value['city']);
    }

	$shipping_city = wp_parse_args( array(
		'type' => 'select',
		'options' => $cityArray,
		/*'input_class' => array(
			'wc-enhanced-select',
		)*/
	), $fields['shipping']['shipping_city'] );
    
    $billing_city = wp_parse_args( array(
		'type' => 'select',
		'options' => $cityArray,
		/*'input_class' => array(
			'wc-enhanced-select',
		)*/
	), $fields['billing']['billing_city'] );
	
	$fields['shipping']['shipping_city'] = $shipping_city;
	$fields['billing']['billing_city'] = $billing_city; // Also change for billing field

/*	wc_enqueue_js( "
	jQuery( ':.wc-enhanced-select' ).filter( ':not(.enhanced)' ).each( function() {
		var select2_args = { minimumResultsForSearch: 5 };
		jQuery( this ).select2( select2_args ).addClass( 'enhanced' );
	});" );
*/
	return $fields;

}

add_filter( 'woocommerce_checkout_fields', 'wc_change_city_to_dropdown' );

/**
 * Change the checkout city field to a dropdown field.
 */
function wc_change_zipcode_to_dropdown( $fields ) {

    global $wpdb;
    $res = $wpdb->get_results("SELECT DISTINCT wczipcode_id,meta_value FROM `{$wpdb->prefix}wc_zipcode_meta` WHERE meta_key = 'zipcode_data'",ARRAY_A);
   
    $zipArray = array();
    $zipArray[""] = "Select Area";
    foreach ($res as $value) {
    $value = unserialize($value["meta_value"]);
    //var_dump($value);die();
    $zipArray[$value["zipcode"]] = $value['area'];
    }


	$zip_args = wp_parse_args( array(
		'type' => 'select',
		'options' => $zipArray,
		'input_class' => array(
			'wc-enhanced-select',
		)
	), $fields['shipping']['billing_postcode'] );

	$fields['shipping']['shipping_postcode'] = $zip_args;
	$fields['shipping']['shipping_postcode']['label'] = 'area';

	$fields['billing']['billing_postcode'] = $zip_args; // Also change for billing field
	$fields['billing']['billing_postcode']['label'] = 'area';

	wc_enqueue_js( "
	jQuery( ':input.wc-enhanced-select' ).filter( ':not(.enhanced)' ).each( function() {
		var select2_args = { minimumResultsForSearch: 5 };
		jQuery( this ).select2( select2_args ).addClass( 'enhanced' );
	});" );

	return $fields;

}
add_filter( 'woocommerce_checkout_fields', 'wc_change_zipcode_to_dropdown' );



add_filter( 'woocommerce_checkout_fields' , 'default_values_checkout_fields' );
  function default_values_checkout_fields( $fields ) {
    // You can use this for postcode, address, company, first name, last name and such. 
    $fields['billing']['billing_city']['default'] = 'Sindh';
    $fields['shipping']['shipping_city']['default'] = 'Sindh';
         return $fields;
  }
