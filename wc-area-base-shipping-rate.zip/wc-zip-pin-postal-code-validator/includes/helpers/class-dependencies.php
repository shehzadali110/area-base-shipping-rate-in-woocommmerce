<?php
/**
 * Dependency Checker
 *
 * Checks if required Dependency plugin is enabled
 *
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/core
 * @since 1.0
 */

if ( ! class_exists( 'woocommerce_zipcode_validation_Dependencies' ) ){
    class woocommerce_zipcode_validation_Dependencies {
		
        private static $active_plugins;
		
        public static function init() {
            self::$active_plugins = (array) get_option( 'active_plugins', array() );
            if ( is_multisite() )
                self::$active_plugins = array_merge( self::$active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );
        }
		
        public static function active_check($pluginToCheck = '') {
            if ( ! self::$active_plugins ) 
				self::init();
            return in_array($pluginToCheck, self::$active_plugins) || array_key_exists($pluginToCheck, self::$active_plugins);
        }
    }
}
/**
 * WC Detection
 */
if(! function_exists('woocommerce_zipcode_validation_Dependencies')){
    function woocommerce_zipcode_validation_Dependencies($pluginToCheck = 'woocommerce/woocommerce.php') {
        return woocommerce_zipcode_validation_Dependencies::active_check($pluginToCheck);
    }
}