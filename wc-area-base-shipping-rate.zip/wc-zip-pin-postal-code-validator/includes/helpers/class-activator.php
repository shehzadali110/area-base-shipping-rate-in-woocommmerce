<?php 
/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/core
 * @since 1.0
 */
class woocommerce_zipcode_validation_Activator {
	
    public static $current_db_version;
    
    public function __construct() {
    }
	
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		require_once(WC_ZIP_V_INC.'helpers/class-version-check.php');
		require_once(WC_ZIP_V_INC.'helpers/class-dependencies.php');
		
		if(woocommerce_zipcode_validation_Dependencies(WC_ZIP_V_DEPEN)){
			woocommerce_zipcode_validation_Version_Check::activation_check('3.7');	
            
            self::get_current_db_version();
            self::table_install();
            self::update_db_version();
            
		} else {
			if ( is_plugin_active(WC_ZIP_V_FILE) ) { deactivate_plugins(WC_ZIP_V_FILE);} 
			wp_die(wc_zipcode_val_dependency_message());
		}
	}
    
    
    
    public static function table_install() {
        $db_create = new woocommerce_zipcode_validation_query;
        $db_create->create_table();
    }   
    
    public static function get_current_db_version(){
        $current_version = get_option(WC_ZIP_V_DB.'db_version');
        self::$current_db_version = $current_version;
    }
 
    public static function update_db_version(){
        update_option(WC_ZIP_V_DB.'db_version',WC_ZIP_V_V);
    }
    
}