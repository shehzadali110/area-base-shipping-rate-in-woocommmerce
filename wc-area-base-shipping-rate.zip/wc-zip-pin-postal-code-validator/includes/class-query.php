<?php
/**
 * Core class used to implement affiliate meta.
 *
 * @since 1.6
 *
 * @see Affiliate_WP_DB
 */
class  woocommerce_zipcode_validation_query {
	/**
	 * Sets up the Affiliate Meta DB class.
	 *
	 * @access public
	 * @since  1.6
	*/
	public function __construct() {
		global $wpdb; 

        $this->table_name  = $wpdb->prefix . 'wc_zipcode_meta'; 
		$this->version     = '1.0'; 
		add_action( 'plugins_loaded', array( $this, 'register_table' ), 11 );
	}
 

    public function register_table() {
		global $wpdb;
		$wpdb->wczipcodemeta = $this->table_name;
	}

    function get_meta( $affiliate_id = 0, $meta_key = '', $single = false ) {
		return get_metadata( 'wczipcode', $affiliate_id, $meta_key, $single );
	}

    function add_meta( $affiliate_id = 0, $meta_key = '', $meta_value = '', $unique = false ) {
		return add_metadata( 'wczipcode', $affiliate_id, $meta_key, $meta_value, $unique );
	}

    function update_meta( $affiliate_id = 0, $meta_key = '', $meta_value = '', $prev_value = '' ) {
		return update_metadata( 'wczipcode', $affiliate_id, $meta_key, $meta_value, $prev_value );
	}

    function delete_meta( $affiliate_id = 0, $meta_key = '', $meta_value = '' ) {
		return delete_metadata( 'wczipcode', $affiliate_id, $meta_key, $meta_value );
	}

    public function create_table() {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		$sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
			meta_id bigint(20) NOT NULL AUTO_INCREMENT,
			wczipcode_id bigint(20) NOT NULL DEFAULT '0',
			meta_key varchar(255) DEFAULT NULL,
			meta_value longtext,
			PRIMARY KEY  (meta_id),
			KEY wczipcode_id (wczipcode_id),
			KEY meta_key (meta_key)
			) CHARACTER SET utf8 COLLATE utf8_general_ci;";
		dbDelta( $sql );
		//update_option( $this->table_name . '_db_version', $this->version );
	}
}