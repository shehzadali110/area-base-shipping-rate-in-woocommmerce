var http_reffer = '';
var addons_html = '';
jQuery(document).ready(function () {
    
    if (jQuery('div.wc_zipcode_val_addon_listing').size() > 0) {
        jQuery('p.submit').remove();
    }
    if (jQuery('.wc_zipcode_val_settings_submenu').size() > 0) {
        var id = window.location.hash;
        jQuery('.wc_zipcode_val_settings_submenu a').removeClass('current');
        jQuery('.wc_zipcode_val_settings_submenu a[href="' + id + '" ]').addClass('current');
        if (id == '') {
            jQuery('.wc_zipcode_val_settings_submenu a:first').addClass('current');
            id = jQuery('.wc_zipcode_val_settings_submenu a:first').attr('href');
        }
        http_reffer = jQuery('input[name=_wp_http_referer').val();

        wc_zipcode_val_settings_showHash(id);
    }
    
    jQuery('.wc_zipcode_val_settings_submenu a').click(function () {
        var id = jQuery(this).attr('href');
        jQuery('.wc_zipcode_val_settings_submenu a').removeClass('current');
        jQuery(this).addClass('current');
        wc_zipcode_val_settings_showHash(id);
        jQuery('input[name=_wp_http_referer').val(http_reffer + id)
    });

    jQuery('.wc_zipcode_val_addon_listing').on('click', '.wc-pbp-activate-now', function () {
        wc_zipcode_val_active_deactive_addon(jQuery(this), '.wc-pbp-deactivate-now');
    });
    
    jQuery('.wc_zipcode_val_addon_listing').on('click', '.wc-pbp-deactivate-now', function () {
        wc_zipcode_val_active_deactive_addon(jQuery(this), '.wc-pbp-activate-now')
    });

    addons_html = jQuery('.wc_zipcode_val_addon_listing').clone();

    jQuery('ul.wc_zipcode_val_addons_category li a:first').addClass('current');

    jQuery('ul.wc_zipcode_val_addons_category li a').each(function () {
        var category = jQuery(this).attr('data-category');
        var catCount = jQuery('.wc-pbp-addon-' + category).size();
        jQuery(this).append(' <span class="catCount"> (' + catCount + ') </span>');
    });

    jQuery('ul.wc_zipcode_val_addons_category li a').click(function () {
        var cat = jQuery(this).attr('data-category');
        var NewDis = 'div.wc-pbp-addon-' + cat;
        jQuery('ul.wc_zipcode_val_addons_category li a').removeClass('current');
        jQuery(this).addClass('current');
        jQuery('.wc_zipcode_val_addon_listing').html(addons_html.find(NewDis).clone());
    });

    jQuery('div.addons-search-form input.wp-filter-search').keyup(function () {
        var val = jQuery(this).val();
        var html_source = addons_html.clone();
        if (val == '') {
            jQuery('.wc_zipcode_val_addon_listing').html(html_source);
            jQuery('.wc-pbp-addon-all').show();
        } else {
            html_source = jQuery(html_source).find(".plugin-card:contains('" + val + "')").not().remove();
            jQuery('.wc_zipcode_val_addon_listing').html(html_source);
        }
    })
    
    
    jQuery("a.wc_zip_v_delete_log").click(function(){
        if(jQuery(this).hasClass("inajaxing")){return;}
        var id = jQuery(this).attr('data-zipcode');
        var t = jQuery(this);
        
        t.toggleClass("inajaxing");
        jQuery(this).parent().append("<span class='spinner is-active'></span>");
        jQuery.ajax({
            url:ajaxurl,
            data:{action:'wc_zipcode_delete',zipcode:id},
            method:"get",
        }).done(function(){
            t.toggleClass('inajaxing');
            t.parent().find('span.spinner').remove();
            t.parent().parent().parent().parent().fadeOut();
            
        })
    })

});

function wc_zipcode_val_settings_showHash(id) {
    jQuery('div.wc_zipcode_val_settings_content').hide();
    id = id.replace('#', '#settings_');
    jQuery(id).show();
}

function wc_zipcode_val_active_deactive_addon(ref, oppo) {
    if (typeof (oppo) === 'undefined') oppo = '.wc-pbp-deactivate-now';
    var clicked = ref;
    var slug = ref.parent().attr('data-pluginslug');
    var parent_div = '.plugin-card-' + slug;
    var height = jQuery(parent_div).innerHeight();
    var width = jQuery(parent_div).innerWidth();
    jQuery(parent_div + ' .wc_zipcode_val_ajax_overlay').css('height', height + 'px').css('width', width + 'px').fadeIn();
    clicked.attr('disabled', 'disable');
    var link = clicked.attr('href');
    jQuery.ajax({
        method: 'GET',
        url: link,
    }).done(function (response) {
        var status = response.success;
        jQuery(parent_div + ' .wc_zipcode_val_ajax_overlay').fadeOut();
        clicked.removeAttr('disabled');
        if (status) {
            clicked.hide();
            jQuery(parent_div).find(oppo).fadeIn();
        }

        jQuery(parent_div).find('.wc_zipcode_val_ajax_response').hide().html(response.data.msg).fadeIn(function () {
            setTimeout(function () {
                jQuery(parent_div).find('.wc_zipcode_val_ajax_response').fadeOut();
            }, 5000);
        });

        jQuery.ajax({
            method: 'GET',
            url: ajaxurl + '?action=wc_zipcode_val_get_addons_html',
        }).done(function (response) {
            addons_html = jQuery(response);
        });
    });

}





  
function wc_zip_add_btn_disable(disable = false){
    if(disable){
        jQuery("div.ajax_errors").html('');
        jQuery("#add_zipcode_force").attr("disabled",'disabled');
        jQuery("#add_zipcode_force").parent().append("<span class='spinner is-active'></span>");
    } else {
        jQuery("#add_zipcode_force").removeAttr("disabled");
        jQuery("#add_zipcode_force").parent().find('span.spinner').remove();
    }
}
    
    

function wc_zipcode_render_wootabs() {
    jQuery('.wczipcode-tab-nav').on('click', 'a', function (e) {
        e.preventDefault();

        var $li = jQuery(this).parent(),
            panel = $li.data('panel'),
            $wrapper = $li.closest('.wczipcode-tabs'),
            $panel = $wrapper.find('.wczipcode-tab-panel-' + panel);

        $li.addClass('wczipcode-tab-active').siblings().removeClass('wczipcode-tab-active');
        $panel.show().siblings().hide();
    });


    if (!jQuery('.wczipcode-tab-active').is('visible')) {
        var activePane = jQuery('.wczipcode-tab-panel[style*="block"]').index();

        if (activePane >= 0) {
            jQuery('.wczipcode-tab-nav li').removeClass('wczipcode-tab-active');
            jQuery('.wczipcode-tab-nav li').eq(activePane).addClass('wczipcode-tab-active');
        }
    }

    jQuery('.wczipcode-tab-active a').trigger('click');
    jQuery('.wczipcode-tabs-no-wrapper').closest('.postbox').addClass('wczipcode-tabs-no-controls');
}


    
function wc_zip_code_validate_existing(value){
    
    jQuery.ajax({
        url : ajaxurl,
        data : {action:'wc_zipcode_validate_admin',zipcode:value},
        method : "GET",
        
    }).done(function(res){
        if(! res.success){
            jQuery("input#service_zipcode").toggleClass("service_zipcode_error");
        } else {
           jQuery("input#service_zipcode").removeClass("service_zipcode_error"); 
        }
        jQuery("div.ajax_errors").html(res.data);
        wc_zip_add_btn_disable(false)
    })
}