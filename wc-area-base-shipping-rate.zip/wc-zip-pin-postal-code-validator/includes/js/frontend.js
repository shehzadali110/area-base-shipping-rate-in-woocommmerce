jQuery(document).ready(function ($) {
    updated_checkout_custom();
    
    jQuery(this).on('change', '.woocommerce-checkout .form-row #billing_postcode', function () {
        updated_checkout_custom();
    });
    
    jQuery(this).on('change', '.woocommerce-checkout .form-row #shipping_postcode', function () {
        updated_checkout_custom();
    });
    
    

    function updated_checkout_custom() {
        //wc_checkout_form.trigger_update_checkout();
        jQuery( 'form.checkout' ).trigger("update");
        return true;        
    }

});