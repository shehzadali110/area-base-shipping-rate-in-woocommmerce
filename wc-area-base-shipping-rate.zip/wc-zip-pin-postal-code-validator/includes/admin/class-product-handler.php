<?php
/**
 * The admin-specific functionality of the plugin.
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/Admin
 * @since 1.0
 */
if ( ! defined( 'WPINC' ) ) { die; }

class woocommerce_zipcode_validation_Admin_Product_Handler {
    
    public function __construct() {
        add_action("woocommerce_product_options_shipping",array($this,'add_product_option'));
    }
    
    public function add_product_option(){
        global $wpdb,$post;
        $sql_data = $wpdb->get_results("SELECT DISTINCT wczipcode_id FROM `{$wpdb->wczipcodemeta}` WHERE `meta_key` = 'is_product' AND `meta_value` = 'yes' ",ARRAY_A);
        $post_data = get_post_meta($post->ID,'_zip_pin_codes',true);
        
        if(empty($post_data)){$post_data = array();}
        $data = wp_list_pluck($sql_data,'wczipcode_id','wczipcode_id');
        
        ?>
<hr/>
        <p class="form-field dimensions_field">
            <label for="zippincodes"><?php echo __( 'Zip/Pin Code', WC_ZIP_V_TXT ); ?></label>
            <button id="product_wczipcodes_update" type="button" class="button button-secondary" style="margin-left:10px !important;"><?php _e("Update Zip/Pin Codes",WC_ZIP_V_TXT); ?></button>
            <?php  echo wc_zipcode_form_field('wczipcodes', array( 
                                'type' => 'select', 
                                'return' => true, 
                                'only_field' => true,
                                'options' => $data,
                                'input_class' => array('wc-enhanced-select'), 
                                'custom_attributes' => array(
                                'multiple' => true ,
                                'style' => 'width:50%;'
                                )
                                ),$post_data); 
            ?>  
        </p>

<script>
jQuery(document).ready(function(){
     jQuery("#product_wczipcodes_update").click(function(){
        var values = jQuery("#wczipcodes").val();
        var th = jQuery(this);
        th.append("<span class='spinner is-active' style='float:none!important'></span>");
        jQuery.ajax({
            url:ajaxurl,
            data:{action:'wc_zipcode_update_product',zipcodes:values,postid:'<?php echo $post->ID; ?>'},
            method:"POST",
        }).done(function(){
            th.find("span.spinner").remove();
        })
    })
})
</script>
        <?php
    }
}



return new woocommerce_zipcode_validation_Admin_Product_Handler;