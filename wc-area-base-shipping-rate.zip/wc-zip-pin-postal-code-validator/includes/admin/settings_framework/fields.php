<?php
global $fields;

$fields['general']['general'][] = array(
    'id' => WC_ZIP_V_DB.'enable_cod_verification', 
    'type'    => 'checkbox',
    'label' => __('Enable COD Verification',WC_ZIP_V_TXT),
    'desc' => __('Enable to validate cod @ checkout based on entered zip/pin code ',WC_ZIP_V_TXT), 
);


$fields['general']['general'][] = array(
    'id' => WC_ZIP_V_DB.'cod_error_msg', 
    'type'    => 'textarea',
    'label' => __('COD Error Message',WC_ZIP_V_TXT),
    'desc' => __('The above message will be displayed if cod is not enabled for entered pin code. | user <code>[zip_pin_code]</code> for user entered zip/pincode ',WC_ZIP_V_TXT), 
    'class' => 'wc-pbp-enhanced-select',
    'attr'     => array(   'style' => 'width:35%;max-width:50%;' ), 
);




$fields['general']['general'][] = array(
    'id' => WC_ZIP_V_DB.'enable_zippincode_verification', 
    'type'    => 'checkbox',
    'label' => __('Enable Zip/Pin Validation',WC_ZIP_V_TXT),
    'desc' => __('If enabled customers can only place orders to the zip/pin codes present in the zip/pin code table. ',WC_ZIP_V_TXT), 
);


$fields['general']['general'][] = array(
    'id' => WC_ZIP_V_DB.'zippincode_verification_msg', 
    'type'    => 'textarea',
    'label' => __('Zip/Pin Code Validation Message',WC_ZIP_V_TXT),
    'desc' => __('The above message will be displayed if entered zip/pin not present in the zip/pin code table. | user <code>[zip_pin_code]</code> for user entered zip/pincode  ',WC_ZIP_V_TXT), 
    'attr'     => array(   'style' => 'width:35%;max-width:50%;' ), 
);







$fields['general']['general'][] = array(
    'id' => WC_ZIP_V_DB.'enable_zippincode_product_verification', 
    'type'    => 'checkbox',
    'label' => __('Enable Zip/Pin Code Product Validation',WC_ZIP_V_TXT),
    'desc' => __('If allow only those products which are enabled at the specific zip/pin codes ',WC_ZIP_V_TXT), 
);


$fields['general']['general'][] = array(
    'id' => WC_ZIP_V_DB.'zippincode_product_verification_msg', 
    'type'    => 'textarea',
    'label' => __('Zip/Pin Code Product  Validation Message',WC_ZIP_V_TXT),
    'desc' => __('The above message will be displayed if entered zip/pin not present in the zip/pin code table. | user <code>[zip_pin_code]</code> for user entered zip/pincode 
    | use [product_name] to get product name which is been removed.
    ',WC_ZIP_V_TXT), 
    'attr'     => array(   'style' => 'width:35%;max-width:50%;' ), 
);
