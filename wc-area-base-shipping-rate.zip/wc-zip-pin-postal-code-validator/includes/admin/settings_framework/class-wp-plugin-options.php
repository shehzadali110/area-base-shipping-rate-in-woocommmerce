<?php
/**
 * The admin-specific functionality of the plugin.
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/Admin
 * @since 3.0
 */
if ( ! defined( 'WPINC' ) ) { die; }

class woocommerce_zipcode_validation_Admin_Settings_Options {

    public function __construct() {
    	add_filter('wc_zipcode_val_settings_pages',array($this,'settings_pages'));
		add_filter('wc_zipcode_val_settings_section',array($this,'settings_section'));
		add_filter('wc_zipcode_val_settings_fields',array($this,'settings_fields'));
    }
	public function settings_pages($page){
		$page[] = array('id'=>'zipcodes','slug'=>'zipcodes','title'=>__('Zip / Pin / Postal Codes ',WC_ZIP_V_TXT));
        $page[] = array('id'=>'bulkimport','slug'=>'bulkimport','title'=>__('Bulk Import ',WC_ZIP_V_TXT));
        $page[] = array('id'=>'general','slug'=>'general','title'=>__('Settings',WC_ZIP_V_TXT));
		//$page[] = array('id'=>'addonssettings','slug'=>'addonssettings','title'=>__('Add-ons Options',WC_ZIP_V_TXT));
		//$page[] = array('id'=>'addons','slug'=>'wc_zipcode_val_addons','title'=>__('Add-ons',WC_ZIP_V_TXT));
		return $page;
	}
	public function settings_section($section){
		$section['general'][] = array( 'id'=>'general', 'title'=> __('',WC_ZIP_V_TXT));
	//	$section['general'][] = array( 'id'=>'advanced', 'title'=> __('Advanced Fields',WC_ZIP_V_TXT));
    //    $section['general'][] = array( 'id'=>'wpfields', 'title'=> __('WP Fields',WC_ZIP_V_TXT));
        
        $section['zipcodes'][] = array( 'id'=>'zipcodes', 'title'=> __('',WC_ZIP_V_TXT));
        $section['bulkimport'][] = array( 'id'=>'bulkimport', 'title'=> __('',WC_ZIP_V_TXT));

        
        /*$section['addons'][] = array( 'id'=>'addons', 'title'=>'');
        
		$addonSettings = array(
            'addon_sample' => array( 'id'=>'addonssettings', 'title'=>__('No Addons Activated / Installed.',WC_ZIP_V_TXT))
        );
		
        $addonSettings = apply_filters('wc_zipcode_val_addon_sections',$addonSettings);

		if(count($addonSettings) > 1) 			
			unset($addonSettings['addon_sample']);
		$section['addonssettings']  = $addonSettings;*/
		return $section;
	}
	public function settings_fields($fields){
        global $fields;
        include(WC_ZIP_V_SETTINGS.'fields.php'); 
        
		$addonSettings = array('addon_sample' => array());
		$addonSettings = apply_filters('wc_zipcode_val_addon_fields',$addonSettings);
		unset($addonSettings['addon_sample']);
		$fields['addonssettings'] = $addonSettings;
	
		return $fields;
	}
}
return new woocommerce_zipcode_validation_Admin_Settings_Options;