<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_Importer' ) ) {
	return;
}
 
class woocommerce_zipcode_validation_importer_handler extends WP_Importer {
 	public $id;
 	public $file_url;
 	public $import_page;
 	public $delimiter;
	public $delimiter_other;

    public function __construct() {
		$this->import_page = 'wc_zipcode_importer';
		$this->delimiter   = empty( $_POST['delimiter'] ) ? ',' : (string) wc_clean( $_POST['delimiter'] );
        $this->delimiter_other   = empty( $_POST['delimiter_other'] ) ? '|' : (string) wc_clean( $_POST['delimiter_other'] );
	}

	/**
	 * Registered callback function for the WordPress Importer.
	 *
	 * Manages the three separate stages of the CSV import process.
	 */
	public function dispatch() {

		$this->header();

		$step = empty( $_GET['step'] ) ? 0 : (int) $_GET['step'];

		switch ( $step ) {

			case 0:
				$this->greet();
				break;

			case 1:
				//check_admin_referer( 'import-upload' );

				if ( $this->handle_upload() ) {

					if ( $this->id ) {
						$file = get_attached_file( $this->id );
					} else {
						$file = ABSPATH . $this->file_url;
					}

					add_filter( 'http_request_timeout', array( $this, 'bump_request_timeout' ) );

					$this->import( $file );
				}
				break;
		}

		$this->footer();
	}

	/**
	 * Import is starting.
	 */
	private function import_start() {
		if ( function_exists( 'gc_enable' ) ) {
			gc_enable();
		}
		wc_set_time_limit( 0 );
		@ob_flush();
		@flush();
		@ini_set( 'auto_detect_line_endings', '1' );
	}

	/**
	 * UTF-8 encode the data if `$enc` value isn't UTF-8.
	 *
	 * @param mixed $data
	 * @param string $enc
	 * @return string
	 */
	public function format_data_from_csv( $data, $enc ) {
		return ( $enc == 'UTF-8' ) ? $data : utf8_encode( $data );
	}

	/**
	 * Import the file if it exists and is valid.
	 *
	 * @param mixed $file
	 */
	public function import( $file ) {
		if ( ! is_file( $file ) ) {
			$this->import_error( __( 'The file does not exist, please try again.', WC_ZIP_V_TXT ) );
		}

		$this->import_start();

        $gateways = wc_zipcode_get_all_payment_method_slugs(true);
        $shipping = wc_zipcode_get_all_shipping_method_slugs(true);
        
		$loop = 0;
        $errors = '';
		if ( ( $handle = fopen( $file, "r" ) ) !== false ) {

			$header = fgetcsv( $handle, 0, $this->delimiter );
            
			if ( 8 === sizeof( $header ) ) {

				while ( ( $row = fgetcsv( $handle, 0, $this->delimiter ) ) !== false ) {
                    if(empty($row[0])){continue;}
                    
                    $exists = metadata_exists('wczipcode',$row[0],'zipcode_data' ) ;
                    if($exists){
                        $msg = __(" <strong>%s</strong> Zip/Pin Code Already Exists ",WC_ZIP_V_TXT);
                        $errors .= sprintf($msg,$row[0]).'<br/>';
                        continue;
                    }
                    
                    $meta_data = array();
                    $meta_data['is_product'] = ($row[1] == 'yes') ? 'yes' : 'no';
                    
                    $for_products = array();
                    $for_products = explode($this->delimiter_other,$row[2]);
                    $for_products = array_combine(array_values($for_products),array_values($for_products));
                    
                    foreach($for_products as $id){
                        $pzip = get_post_meta($id,'_zip_pin_codes',true);
                        if(empty($pzip)){$pzip = array();}
                        if(! isset($pzip[$row[0]])){
                            $pzip[$row[0]] = $row[0];
                        }
                        update_post_meta($id,'_zip_pin_codes',$pzip);
                    }
                    //var_dump($row);die();
                    $meta_data['country'] = $row[4];
                    $meta_data['zipcode'] = $row[0];

                    $meta_data['state'] = $row[5];
                    $meta_data['city'] = $row[6];
					 $meta_data['area'] = $row[7];
                    $meta_data['shipping_methods'] = array();
                    $meta_data['payment_gateway'] = array();
                    
                    if(!empty($row[7])){
                        $selected_shipping = explode($this->delimiter_other,$row[7]);
                        
                        foreach($selected_shipping as $ship){
                            if($gate == 'all'){
                                $meta_data['shipping_methods'] = array_keys($gateways);
                            }else if(isset($shipping[$ship])){
                                $meta_data['shipping_methods'][] = $ship;
                            } else {
                                $msg = __("Zip/Pin Code (<strong>%s</strong>) Shipping Method (<strong>%s</strong>) Does Not Exists !",WC_ZIP_V_TXT);
                                $errors .= sprintf($msg,$row[0],$ship).'<br/>';
                            }
                        }
                    }
                    if(!empty($row[8])){
                        $selected_gateway = explode($this->delimiter_other,$row[8]);
                        
                        foreach($selected_gateway as $gate){ 
                            if($gate == 'all'){
                                $meta_data['payment_gateway'] = array_keys($gateways);
                            } else if($gate == 'prepaid'){
                                $meta_data['payment_gateway'] = array_keys($gateways);
                            } else if(isset($gateways[$gate])){
                                $meta_data['payment_gateway'][] = $gate;
                            } else {
                                $msg = __("Zip/Pin Code (<strong>%s</strong>) Payment Gateway (<strong>%s</strong>) Does Not Exists !",WC_ZIP_V_TXT);
                                $errors .= sprintf($msg,$row[0],$gate).'<br/>';
                            }
                        }
                    }
                    
                    $meta_data['shipping_methods'] = array_unique($meta_data['shipping_methods']);
                    $meta_data['payment_gateway'] = array_unique($meta_data['payment_gateway']);
                    
                    $status = wc_add_zipcode($row[0], 'zipcode_data', $meta_data, false);
                    $status = wc_add_zipcode($row[0], 'is_product', $meta_data['is_product'], false);
                    $status = wc_add_zipcode($row[0], 'product_ids', $for_products, false);
                    
                    
                    
                    if(! $status){
                        $msg = __(" <strong>%s</strong> Zip/Pin Code Creation Failed ! ",WC_ZIP_V_TXT);
                        $errors .= sprintf($msg,$row[0]).'<br/>';
                    }

                    $loop++;
				}
                
			} else {
				$this->import_error( __( 'The CSV is invalid.', WC_ZIP_V_TXT ) );
			}

			fclose( $handle );
		}

		// Show Result
		echo '<div class="updated settings-error"><p>
			' . sprintf( __( 'Import complete -  <strong>%s</strong> Pin/Zip Codes Created .', WC_ZIP_V_TXT ), $loop ) . '
		</p></div>';

        if(!empty($errors)){
             echo '<div class="error settings-error"><p>
            ' . sprintf( __( 'Import Errors -.', WC_ZIP_V_TXT ), $loop ) . '
        </p>
        <p>'.$errors.'</p>
        </div>';
        }
       

		$this->import_end();
	}

	/**
	 * Performs post-import cleanup of files and the cache.
	 */
	public function import_end() { 
		do_action( 'import_end' );
	}

	/**
	 * Handles the CSV upload and initial parsing of the file to prepare for.
	 * displaying author import options.
	 *
	 * @return bool False if error uploading or invalid file, true otherwise
	 */
	public function handle_upload() {
		if ( empty( $_POST['file_url'] ) ) {

			$file = wp_import_handle_upload();

			if ( isset( $file['error'] ) ) {
				$this->import_error( $file['error'] );
			}

			$this->id = absint( $file['id'] );

		} elseif ( file_exists( ABSPATH . $_POST['file_url'] ) ) {
			$this->file_url = esc_attr( $_POST['file_url'] );
		} else {
			$this->import_error();
		}

		return true;
	}

	/**
	 * Output header html.
	 */
	public function header() {
		echo '<div class="wrap"><div class="icon32" id=""><br></div>';
		echo '<h1>' . __( 'WC Zip/Pin Code Importer', WC_ZIP_V_TXT ) . '</h1>';
	}

	/**
	 * Output footer html.
	 */
	public function footer() {
		echo '</div>';
	}

	/**
	 * Output information about the uploading process.
	 */
	public function greet() {
        echo '<style>
            .wrap > h1 {display:none !important;}
            p.submit{display:none !important;}
        </style>';
		echo '<div class="narrow">';
        
		echo '<p>' . sprintf( __( 'CSV need to be defined with columns in a specific order (8 columns). <a href="%s">Click here to download a sample</a>.', WC_ZIP_V_TXT ), WC_ZIP_V_URL . 'sample-data/pincodes.csv' ) . '</p>';

		$action = 'admin.php?page=wooCommerce-area-base-shipping-rate-settings&tab=bulkimport&step=1';

		$bytes = apply_filters( 'import_upload_size_limit', wp_max_upload_size() );
		$size = size_format( $bytes );
		$upload_dir = wp_upload_dir();
		if ( ! empty( $upload_dir['error'] ) ) :
            
			?><div class="error"><p><?php _e( 'Before you can upload your import file, you will need to fix the following error:', WC_ZIP_V_TXT ); ?></p>
			<p><strong><?php echo $upload_dir['error']; ?></strong></p></div><?php
		else :
			?>
</form>
			<form enctype="multipart/form-data" id="import-upload-form" method="post" action="<?php echo esc_attr(wp_nonce_url($action, 'import-upload')); ?>">
				<table class="form-table">
					<tbody>
						<tr>
							<th>
								<label for="upload"><?php _e( 'Choose a file from your computer:', WC_ZIP_V_TXT ); ?></label>
							</th>
							<td>
								<input type="file" id="upload" name="import" size="25" />
								<input type="hidden" name="action" value="save" />
								<input type="hidden" name="max_file_size" value="<?php echo $bytes; ?>" />
								<small><?php printf( __('Maximum size: %s', WC_ZIP_V_TXT ), $size ); ?></small>
							</td>
						</tr>
						<tr>
							<th>
								<label for="file_url"><?php _e( 'OR enter path to file:', WC_ZIP_V_TXT ); ?></label>
							</th>
							<td>
								<?php echo ' ' . ABSPATH . ' '; ?><input type="text" id="file_url" name="file_url" size="25" />
							</td>
						</tr>
						<tr>
							<th><label><?php _e( 'Delimiter', WC_ZIP_V_TXT ); ?></label><br/></th>
							<td><input type="text" name="delimiter" placeholder="," size="2" /></td>
						</tr>
                        <tr>
							<th><label><?php _e( 'Multiple Option Delimiter', WC_ZIP_V_TXT ); ?></label><br/></th>
							<td><input type="text" name="delimiter_other" placeholder="|" size="2" />
                                <code><strong><?php _e("Note : ",WC_ZIP_V_TXT); ?> </strong>
                                <?php _e("Both Multiple Option Delimiter & Delimiter Should not be the same. please use different values. also this should match the files. download sample to check",WC_ZIP_V_TXT); ?>
                                </code>
                            </td>
						</tr>
					</tbody>
				</table>
                
                
                
				<p class="submit" style="display:block !important;">
					<input type="submit" class="button" value="<?php esc_attr_e( 'Upload file and import', WC_ZIP_V_TXT ); ?>" />
				</p>
                
                <div style="width: auto;float: left !important;display: inline-block !important;maring-left:10px;">
                    <h3><?php _e("Payment Gateway Slug",WC_ZIP_V_TXT); ?></h3>
                    <table class="widefat fixed striped" style="width: auto">
                        <thead> <tr> <th><?php _e("Name",WC_ZIP_V_TXT); ?></th> <th><?php _e("Slug",WC_ZIP_V_TXT); ?></th> </tr> </thead>
                        <tfoot> <tr> <th><?php _e("Name",WC_ZIP_V_TXT); ?></th> <th><?php _e("Slug",WC_ZIP_V_TXT); ?></th>  </tr> </tfoot>                    
                        <tbody>
                            <?php 
                                $roles = wc_zipcode_get_all_payment_method_slugs(true);
                                foreach($roles as $slug => $name){
                                    echo '<tr><td>'.$name.'</td><td>'.$slug.'</td></tr>';
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="width: auto; display: inline-block !important; margin-left:50px !important;">
                    <h3><?php _e("Shipping Method Slug",WC_ZIP_V_TXT); ?></h3>
                    <table class="widefat fixed striped" style="width: auto">
                        <thead> <tr> <th><?php _e("Name",WC_ZIP_V_TXT); ?></th> <th><?php _e("Slug",WC_ZIP_V_TXT); ?>  </th> </tr> </thead>
                        <tfoot> <tr> <th><?php _e("Name",WC_ZIP_V_TXT); ?></th> <th><?php _e("Slug",WC_ZIP_V_TXT); ?> </th>  </tr> </tfoot>                    
                        <tbody>
                            <?php 
                                $roles = wc_zipcode_get_all_shipping_method_slugs(true);
                                foreach($roles as $slug => $name){
                                    echo '<tr><td>'.$name.'</td><td>'.$slug.'</td></tr>';
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
			</form>
<form>
			<?php
		endif;

		echo '</div>';
	}

	/**
	 * Show import error and quit.
	 * @param  string $message
	 */
	private function import_error( $message = '' ) {
        if(isset($_REQUEST['step'])){
            wp_redirect(admin_url('admin.php?page=wooCommerce-area-base-shipping-rate-settings&tab=bulkimport'));
        }
		echo '<p><strong>' . __( 'Sorry, there has been an error.', WC_ZIP_V_TXT ) . '</strong><br />';
		if ( $message ) {
			echo esc_html( $message );
		}
		echo '</p>';
		$this->footer();
		die();
	}

	/**
	 * Added to http_request_timeout filter to force timeout at 60 seconds during import.
	 *
	 * @param  int $val
	 * @return int 60
	 */
	public function bump_request_timeout( $val ) {
		return 60;
	}
}
