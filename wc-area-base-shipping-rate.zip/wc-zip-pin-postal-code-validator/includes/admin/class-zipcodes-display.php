<?php
/**
 * The admin-specific functionality of the plugin.
 * @link http://wordpress.org/plugins/woocommerce-international-sms
 * @package WCISMS
 * @subpackage WCISMS/Admin
 * @since 1.0
 */
if ( ! defined( 'WPINC' ) ) { die; }

class woocommerce_zipcode_validation_admin_display {
    
    public function __construct() {
        add_action(WC_ZIP_V_DB.'_form_fields',array($this,'list_addons'),10,2);
    }
    
    public function list_addons($none,$form_id){
        if($form_id == 'zipcodes'){
            wc_zip_code_tt_render_list_page();
        }
        
        if($form_id == 'bulkimport'){
            if(!class_exists('WP_Importer')){
                require_once( ABSPATH . 'wp-admin/includes/class-wp-importer.php' );
            } 
            
            include(WC_ZIP_V_ADMIN."class-importer-handler.php");
            $importer =  new woocommerce_zipcode_validation_importer_handler;
            
            $importer->dispatch();
        }
	}
}


if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
} 


if(!function_exists('wc_zipcode_get_item')){
    function wc_zipcode_get_item($key = '',$item){
        //$i = maybe_unserialize($item['meta_value']);
        $i = $item;
        $return = isset($i[$key]) ? $i[$key] : false;
        $return = maybe_unserialize($return);
        return $return;
    }
}

class woocommerce_zipcode_validation_admin_display_table extends WP_List_Table {
    
    
     
    /** ************************************************************************
     * REQUIRED. Set up a constructor that references the parent constructor. We 
     * use the parent reference to set some default configs.
     ***************************************************************************/
    function __construct(){
        global $status, $page; 
        
        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'zipcode',     //singular name of the listed records
            'plural'    => 'zipcodes',    //plural name of the listed records
            'ajax'      => true        //does this table support ajax?
        ) );
        
    }

    
    function column_default($item, $column_name){
       return print_r(1,true); //Show the whole array for troubleshooting purposes
    }
     
    
    
    
    function column_zipcode($item){
        $zipcode = $item['wczipcode_id'];
        $edit_link = admin_url('admin-ajax.php?action=wc_zipcode_edit&zipcode='.$zipcode);
        $viewLink = admin_url('admin-ajax.php?action=wc_zipcode_product_view&zipcode='.$zipcode);
        $title = sprintf(__("Editing %s Zip/Pin Code",WC_ZIP_V_TXT),$zipcode);
        $actions = array(
            'edit'   => sprintf('<a href="%s" title="%s" class="thickbox">Edit</a>',$edit_link,$title),
            'delete'    => sprintf('<a href="javascript:void(0);" class="wc_zip_v_delete_log" data-zipcode="%s" >Delete</a>',$zipcode),
            'view_products'    => sprintf('<a href="%s" class="thickbox" title="%s %s">%s</a>',$viewLink,__("Products For : ",WC_ZIP_V_TXT),$zipcode,__("View Products",WC_ZIP_V_TXT)),
        );
        
        //Return the title contents
        return sprintf('%1$s %2$s',
            /*$1%s*/ $zipcode, 
            /*$3%s*/ $this->row_actions($actions)
        );
    }
    
    function column_payment($item){
        $type = wc_zipcode_get_item('payment_gateway',$item);
        if(!$type){return '';}
        $return = null;
        $error = null;
        if(is_array($type)){
            $gateways = wc_zipcode_get_all_payment_method_slugs(true);
            foreach($type as $id){
                if(isset($gateways[$id])){
                    $return .= $gateways[$id].', ';
                } else if(!isset($gateways[$id])){
                     $error .=  $id.', ';
                }
            }
        }
        
        if(!is_null($error)){
            $error = '<br/> <br/> <span style="color:red"> '.__("Invalid Gateway : ",WC_ZIP_V_TXT).'</span> '.$error;
        }
        
        return $return.$error;
    }
    
    
    
    function column_shipping($item){
        $type = wc_zipcode_get_item('shipping_methods',$item);
        if(!$type){return '';}
        $return = null;
        $error = null;
        if(is_array($type)){
            $gateways = wc_zipcode_get_all_shipping_method_slugs(true); 
            foreach($type as $id){
                if(isset($gateways[$id])){
                    $return .= $gateways[$id].', ';
                } else if(!isset($gateways[$id])){
                     $error .=  $id.',';
                }
            }
        }
        
        if(!is_null($error)){
            $error = '<br/> <br/> <span style="color:red"> '.__("Invalid Shipping Methods : ",WC_ZIP_V_TXT).'</span> '.$error;
        }
        
        return $return.$error;
    }
    
     
    function column_city($item){
        $type = wc_zipcode_get_item('city',$item);
        return $type;
    }
    function column_area($item){
        $type = wc_zipcode_get_item('area',$item);
        return $type;
    }
    function column_country($item){
        $type = wc_zipcode_get_item('country',$item);
        $countries = WC()->countries->get_shipping_countries();
        return isset($countries[$type]) ? $countries[$type] : $type; 
    }

    
    function column_state($item){
        $type = wc_zipcode_get_item('state',$item); 
        return $type;
    }
    
    function column_enable_product($item){
        $type = wc_zipcode_get_item('is_product',$item);
        if($type == 'yes'){
            return '<span style="margin:0 auto" class="status-enabled"></span>';
        }
        return '<span style="margin:0 auto" class="status-disabled"></span>';
    }

    
    function column_cb($item){
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            /*$1%s*/ $this->_args['singular'],  //Let's simply repurpose the table's singular label ("movie")
            /*$2%s*/ $item['wczipcode_id']                //The value of the checkbox should be the record's id
        );
    }

    function get_columns(){
        $columns = array(
            'cb'        => '<input type="checkbox" />', //Render a checkbox instead of text
            'zipcode'        => __('Zip/Pin Code',WC_ZIP_V_TXT), //Render a checkbox instead of text
            'enable_product'        => __('Specific Products',WC_ZIP_V_TXT), //Render a checkbox instead of text
            'payment'     => __('Payment Gateway',WC_ZIP_V_TXT),
            'shipping'     => __('Shipping Methods',WC_ZIP_V_TXT),
            'country'    => __('Country',WC_ZIP_V_TXT),
            'state'  => __("State",WC_ZIP_V_TXT),
            'city'  => __("City",WC_ZIP_V_TXT),
			'area'  => __("Area",WC_ZIP_V_TXT),
        );
        return $columns;
    }

 
    function get_sortable_columns() {
        $sortable_columns = array(
            'zipcode'     => array('zipcode',true),     //true means it's already sorted
            'country'    => array('country',false),
            'state' => array('state',false),
        );
        return $sortable_columns;
    }

 
    function get_bulk_actions() {
        $actions = array(
            'delete'    => 'Delete'
        );
        return $actions;
    }
 
    function process_bulk_action() {  
        if( 'delete'===$this->current_action() ) {
            $sendback = remove_query_arg( array('action', 'action2', 'paged', 'locked', 'zipcode'), wp_get_referer() );
            if(isset($_REQUEST['zipcode'])){
                $ids = $_REQUEST['zipcode'];
                
                
                $deleted = array();
                $errors = array();
                
                foreach($ids as $id){
                    $del_status = wc_delete_zipcode($id,'zipcode_data');
                    if($del_status){
                        $deleted[] = $id;
                    } else {
                        $errors[] = $id;
                    } 
                }
                
                
                if(!empty($deleted)){
                    $message = __("Following Zip/Pin Code Deleted Successfully : %s ");
                    $ids = implode(',',$deleted);
                    $message = sprintf($message,$ids);
                    wc_zipcode_val_admin_update( $message,1,'wczipcodedellok');
                }
                
                if(!empty($errors)){
                    $message = __("Unable to delete the following zip/pin code : %s  <br/> it may be already deleted.");
                    $ids = implode(',',$errors);
                    $message = sprintf($message,$ids);
                    wc_zipcode_val_admin_error( $message,1,'wczipcodedelfail');
                }
                
                wp_redirect($sendback);
 
            }
        }
        
    }
    
     
    
	public function single_row( $item ) {
		echo '<tr class="wc_zip_v_'.$item['meta_id'].'">';
		$this->single_row_columns( $item );
		echo '</tr>';
	}
    
	/**
	 * Extra controls to be displayed between bulk actions and pagination
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @param string $which
	 */
	protected function extra_tablenav( $which ) {
        if($which != 'top'){return;}
        $value = isset($_REQUEST['per_page']) ? $_REQUEST['per_page'] : 5;
        echo 'Items Per Page : <input step="1" min="1" max="999" class="screen-per-page" name="per_page" id="items_perpage" maxlength="3" value="'.$value.'" type="number"> ';
        
        echo '<a class="button right thickbox button-primary" style="margin-left:10px;" title="'.__("Add New Zip/Pin Code",WC_ZIP_V_TXT).'"  href="'.admin_url('admin-ajax.php?action=wc_zipcode_add_new&height=400&width=600').'" >
        '.__("Add New Zip/Pin Code",WC_ZIP_V_TXT).'</a>';
        
    }
    
    
	/**
	 * Generate the table navigation above or below the table
	 *
	 * @since 3.1.0
	 * @access protected
	 * @param string $which
	 */
	protected function display_tablenav( $which ) { 
		?>
	<div class="tablenav <?php echo esc_attr( $which ); ?>">

		<?php if ( $this->has_items() ): ?>
		<div class="alignleft actions bulkactions">
			<?php $this->bulk_actions( $which ); ?>
            
		</div>
		<?php endif;
		$this->extra_tablenav( $which );
		$this->pagination( $which );
?>

		<br class="clear" />
	</div>
<?php
	}
   
    
	protected function set_pagination_args( $args ) {
		$args = wp_parse_args( $args, array(
			'total_items' => 0,
			'total_pages' => 0,
			'per_page' => 0,
		) );

		if ( !$args['total_pages'] && $args['per_page'] > 0 )
			$args['total_pages'] = ceil( $args['total_items'] / $args['per_page'] );

        $this->_pagination_args = $args;
	}
    
    function prepare_items() {
        global $wpdb; //This is used only if making any database queries

        $per_page =  isset($_REQUEST['per_page']) ? $_REQUEST['per_page'] : 5;
        
        $sql_data = $wpdb->get_results("SELECT DISTINCT wczipcode_id,meta_id, meta_value FROM `{$wpdb->wczipcodemeta}` WHERE meta_key = 'zipcode_data'",ARRAY_A);
        
        $data = array();
        foreach($sql_data as $d){
            $meta = maybe_unserialize($d['meta_value']);
            $data[$d['wczipcode_id']] = array_merge(array('wczipcode_id' => $d['wczipcode_id'],'meta_id' => $d['meta_id']),$meta);
        }
        
        function usort_reorder($a,$b){ 
            $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'wczipcode_id'; //If no sort, default to title
            if($orderby =='zipcode'){$orderby = 'wczipcode_id';}
            $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'decs'; //If no order, default to asc
          //  $a = wc_zipcode_get_item($orderby,$a['meta_value']);
          //  $b = wc_zipcode_get_item($orderby,$b['meta_value']);
            
            $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
            return ($order==='asc') ? $result : -$result; //Send final sort direction to usort
        }
        
        usort($data, 'usort_reorder');
        
        $current_page = $this->get_pagenum();
        $total_items = count($data);
        $data = array_slice($data,(($current_page-1)*$per_page),$per_page);
        $this->items = $data;
        
        $this->set_pagination_args( array(
            'total_items' => $total_items,                  //WE have to calculate the total number of items
            'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
            'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
        ) );
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->process_bulk_action();
    }


}

  
function wc_zip_code_tt_render_list_page(){ 
    $testListTable = new woocommerce_zipcode_validation_admin_display_table(); 
    $testListTable->prepare_items();
    add_thickbox();  
    $current_url = set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] );  
    ?>  
        </form>
        <form id="wczipcode-filter" method="get" action="<?php echo $current_url; ?> "> 
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
            <input type="hidden" name="tab" value="zipcodes" />
            <br/>
            
            <?php $testListTable->display() ?> 
</form>
<style>#zipcodes{display:none !important; }</style>
<form method="post">
    
    <?php
}

 

return new woocommerce_zipcode_validation_admin_display;