<?php
/**
 * The admin-specific functionality of the plugin.
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/Admin
 * @since 3.0for_products
 */
if ( ! defined( 'WPINC' ) ) { die; }

class woocommerce_zipcode_validation_Admin_Ajax_Handler {
    
    public function __construct() { 
		add_action( 'wp_ajax_nopriv_wc_zipcode_val_addon_custom_css',array($this,'render_addon_css'));
		add_action( 'wp_ajax_wc_zipcode_val_addon_custom_css',array($this,'render_addon_css'));
        add_action( 'wp_ajax_nopriv_wc_zipcode_val_addon_custom_js',array($this,'render_addon_js'));
		add_action( 'wp_ajax_wc_zipcode_val_addon_custom_js',array($this,'render_addon_js'));
        
        add_action("wp_ajax_wc_zipcode_add_new",array($this,'render_add_new_form'));
        
        add_action("wp_ajax_wc_zipcode_validate_admin",array($this,'validate_zipcode'));
        add_action("wp_ajax_wc_add_zipcode_admin",array($this,'add_zipcode')); 
        
        add_action("wp_ajax_wc_zipcode_edit",array($this,'render_edit_zipcode'));
        add_action("wp_ajax_wc_zipcode_delete",array($this,'delete_zipcode'));
        
        add_action("wp_ajax_wc_zipcode_product_view",array($this,'zipcode_product_view'));
        
        add_action("wp_ajax_wc_zipcode_remove_product",array($this,'zipcode_remove_product'));
        add_action("wp_ajax_wc_zipcode_update_product",array($this,'zipcode_remove_from_product'));
    }
    
    public function zipcode_remove_from_product(){
        $post_id = $_REQUEST['postid'];
        $zipcodes = $_POST['zipcodes'];
        $pzip = get_post_meta($post_id,'_zip_pin_codes',true); 
        $new_pin = array_combine(array_values($zipcodes),array_values($zipcodes));
        if(empty($new_pin)){$new_pin =  array();}
        
        
        $removed = array_diff($new_pin,$pzip);
        if(empty($removed)){ $removed = array_diff($pzip,$new_pin); }
        if(is_array($removed)){
            foreach($removed as $r){
                if(empty($r)){continue;}
                $products = wc_get_zipcode($r, 'product_ids',true); 
                
                if(isset($new_pin[$r])){
                    $products[$post_id] = $post_id;   
                } else {
                    if(isset($products[$post_id])){ unset($products[$post_id]); } 
                }
                
                wc_update_zipcode($r, 'product_ids',$products);
            }    
        }
        
        
        update_post_meta($post_id,'_zip_pin_codes',$new_pin); 
        wp_die();
    }
    
    public function zipcode_remove_product(){
        if(isset($_REQUEST['zipcode'])){
            $code = $_REQUEST['zipcode'];
            $exists = metadata_exists('wczipcode',$code,'zipcode_data' ) ;
            if($exists){
                if(isset($_REQUEST['product'])){
                    $product = $_REQUEST['product'];
                    $pzip = get_post_meta($product,'_zip_pin_codes',true); 
                    if(isset($pzip[$code])){ unset($pzip[$code]); }
                    update_post_meta($product,'_zip_pin_codes',$pzip);
                    
                    $products = wc_get_zipcode($code, 'product_ids',true); 
                    if(isset($products[$product])){ unset($products[$product]); }
                    wc_update_zipcode($code, 'product_ids',$products);
                    wp_send_json_success();
                }
            }
        }
        
        wp_send_json_error();
    }
    
    
    public function zipcode_product_view(){
        if(isset($_REQUEST['zipcode'])){
            $code = $_REQUEST['zipcode'];
            $exists = metadata_exists('wczipcode',$code,'zipcode_data' ) ;
            if(! $exists){
                $msg = sprintf(__("<h2>Zip/Pin Code (%s) Dose Not Exists</h2>",WC_ZIP_V_TXT),$code);
                wp_die($msg);
            } else {
                $product_data = wc_get_zipcode($code, 'product_ids',true); 
                if(!empty($product_data)){
                    include(WC_ZIP_V_ADMIN.'views/view_products.php');    
                } else {
                    $msg = sprintf(__("<h2>No Products Selected </h2>",WC_ZIP_V_TXT),$code);
                    wp_die($msg);
                }
            }
        } else {
            $msg = __("<h2> Unable To Edit  Zip/Pin Code. Try Again! </h2>",WC_ZIP_V_TXT);
            wp_die($msg);
        }
        wp_die();
    }
    
    public function render_add_new_form(){
        $is_editing = false; 
        $metadata = array('product_data' => '', 'is_product' => '', 'zipcode' => '',  'country' => '','state' => '','city' => '','area' => '', 'shipping_methods' => array(),'payment_gateway' => array(),'zipcode' => '',);
        include(WC_ZIP_V_ADMIN.'views/add_new_form.php');
        wp_die();
    }
    
    public function render_edit_zipcode(){
        if(isset($_REQUEST['zipcode'])){
            $code = $_REQUEST['zipcode'];
            $exists = metadata_exists('wczipcode',$code,'zipcode_data' ) ;
            if(! $exists){
                $msg = sprintf(__("<h2>Zip/Pin Code (%s) Dose Not Exists</h2>",WC_ZIP_V_TXT),$code);
                wp_die($msg);
            } else {
                $is_editing = true;
                $metadata = wc_get_zipcode($code, 'zipcode_data',true);
                $is_product = wc_get_zipcode($code, 'is_product',true);
                $product_data = wc_get_zipcode($code, 'product_ids',true); 
                $metadata['zipcode'] =  $code;
                $metadata['product_data'] = $product_data;
                $metadata['is_product'] = $is_product;
                include(WC_ZIP_V_ADMIN.'views/add_new_form.php');    
            }
        } else {
            $msg = __("<h2> Unable To Edit  Zip/Pin Code. Try Again! </h2>",WC_ZIP_V_TXT);
            wp_die($msg);
        }
        wp_die();
    }

    public function delete_zipcode(){
        if(isset($_REQUEST['zipcode'])){
            $del_status = wc_delete_zipcode($_REQUEST['zipcode'],'zipcode_data');
            $del_status = wc_delete_zipcode($_REQUEST['zipcode'],'product_ids');
            $del_status = wc_delete_zipcode($_REQUEST['zipcode'],'is_product');
            wp_send_json_error();
        }
        wp_send_json_error();
    }
    
    public function remove_code_from_product($code){
        $ids = wc_get_zipcode($code,'product_ids',true);
        if(!empty($ids)){
            foreach($ids as $id){
                $pzip = get_post_meta($id,'_zip_pin_codes',true);
                
                if(!empty($pzip)){
                    if(isset($pzip[$code])){
                        unset($pzip[$code]);
                    }
                }
                
                update_post_meta($id,'_zip_pin_codes',$pzip);
            }
        }
    }
    
    public function add_code_from_product($code,$product_ids){ 
        if(!empty($product_ids)){
            foreach($product_ids as $id){
                $pzip = get_post_meta($id,'_zip_pin_codes',true);
                if(empty($pzip)){$pzip = array();}
                if(! isset($pzip[$code])){
                    $pzip[$code] = $code;
                }
                update_post_meta($id,'_zip_pin_codes',$pzip);
            }
        }
    }
    
    
    
    public function add_zipcode(){
       if(isset($_REQUEST['service_zipcode'])){
            $code = $_REQUEST['service_zipcode'];
            $exists = metadata_exists('wczipcode',$code,'zipcode_data' );
           
            if($exists){
                if($_REQUEST['wc_zip_force_edit']){
                    $zipcode = $_REQUEST['service_zipcode'];
                    $meta_data = $_REQUEST['meta']; 
                    $meta_data['zipcode']  = $zipcode;
                    $is_product = isset($meta_data['is_product']) ? 'yes' : 'no';
                    $for_products = isset($_REQUEST['for_products']) ? $_REQUEST['for_products'] : array();
                    if(is_string($for_products)){
                        $for_products = explode(',',$for_products);
                        $for_products = array_combine(array_values($for_products),array_values($for_products));
                    }
                    
                    $meta_data['product_ids'] = md5(json_encode($for_products));
                    $meta_data['is_product'] = $is_product;

                    
                    
                    $this->remove_code_from_product($zipcode);
                    $this->add_code_from_product($zipcode,$for_products);
                    
                    $status = wc_update_zipcode($zipcode, 'is_product', $is_product, false);
                    $status = wc_update_zipcode($zipcode, 'product_ids', $for_products, false);
                    $status = wc_update_zipcode($zipcode, 'zipcode_data', $meta_data, false);
                    
                    if($status){
                        $msg = __("Zip/Pin Code Edited Successfully | %s ",WC_ZIP_V_TXT);
                        $msg = sprintf($msg,$code);
                        $value = wc_zipcode_val_admin_notice($msg,  'updated');
                        wp_send_json_success($value);
                    }  else {
                        $msg = __("Zip/Pin Code Edited Failed | %s ",WC_ZIP_V_TXT);
                        $msg = sprintf($msg,$code);
                        $value = wc_zipcode_val_admin_notice($msg,  'error');
                        wp_send_json_success($value);
                    }
                } else {
                    $msg = __("Entered Pincode / Zipcode Already Exists. ",WC_ZIP_V_TXT);
                    $value = wc_zipcode_val_admin_notice($msg ,  'error');
                    wp_send_json_error($value);    
                }
                
            } else {
                $zipcode = $_REQUEST['service_zipcode'];
                $meta_data = $_REQUEST['meta']; 
                $is_product = isset($meta_data['is_product']) ? 'yes' : 'no';
                $for_products = isset($_REQUEST['for_products']) ? $_REQUEST['for_products'] : array();
                if(is_string($for_products)){
                    $for_products = explode(',',$for_products);
                    $for_products = array_combine(array_values($for_products),array_values($for_products));
                }
                
                
                $meta_data['product_ids'] = md5(json_encode($for_products));
                $meta_data['is_product'] = $is_product;
                $meta_data['zipcode']  = $zipcode;
                
                
                $this->remove_code_from_product($zipcode);
                $this->add_code_from_product($zipcode,$for_products);
                
                $status = wc_add_zipcode($zipcode, 'is_product', $is_product, false);
                $status = wc_add_zipcode($zipcode, 'product_ids', $for_products, false);
                $status = wc_add_zipcode($zipcode, 'zipcode_data', $meta_data, false);
                
                if($status){
                    $msg = __("Zip/Pin Code Added Successfully | %s ",WC_ZIP_V_TXT);
                    $msg = sprintf($msg,$zipcode);
                    $value = wc_zipcode_val_admin_notice($msg,  'updated');
                    wp_send_json_success($value);
                } 
                
                $value = wc_zipcode_val_admin_notice(__("Unabel To Add Zip/Pin Code Please Try Again !",WC_ZIP_V_TXT) ,  'error');
                wp_send_json_error($value);
            }
            
        } else {
            $value = wc_zipcode_val_admin_notice(__("Please Enter A Valid Pin/Zip Code",WC_ZIP_V_TXT) ,  'error');
            wp_send_json_error($value);
        }
        
        wp_die(); 
    }
    public function validate_zipcode(){
        if(isset($_REQUEST['zipcode'])){
            $code = $_REQUEST['zipcode'];
            $exists = metadata_exists('wczipcode',$code,'zipcode_data' ) ;
            if($exists){
                $msg = __("Entered Pincode / Zipcode Already Exists. ",WC_ZIP_V_TXT);
                $value = wc_zipcode_val_admin_notice($msg ,  'error');
                wp_send_json_error($value); 
            } else {
                wp_send_json_success('');
            }
            
        } else {
            $value = wc_zipcode_val_admin_notice(__("Please Enter A Valid Pin/Zip Code",WC_ZIP_V_TXT),  'error');
            wp_send_json_error($value);
        }
        
        wp_die();
    }
    
  
    
    public function render_addon_css(){ 
        header('Content-Type: text/css');
		do_action('wc_zipcode_val_addon_styles');
		wp_die();
	}
	public function render_addon_js(){ 
        header('Content-Type: text/javascript'); 
		do_action('wc_zipcode_val_addon_scripts'); 
		wp_die();
	}
}