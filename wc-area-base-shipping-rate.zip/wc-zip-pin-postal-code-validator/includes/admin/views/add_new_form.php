<br/>

<div class="ajax_errors" style="min-height:25px; padding:5px 0; margin:5px 0;margin-top: 0;"></div>

<div class="wczipcode_tab_wrapper" id="wczipcode_form_wrapper" style="display: block ! important; border: 1px solid rgb(204, 204, 204); margin: 10px 0;">
    <?php
        $gateways = wc_zipcode_get_all_payment_method_slugs(true);
        $shippings = wc_zipcode_get_all_shipping_method_slugs(true);
    
        $content = array();
    
        $content['general'] = '';
        $content['other'] = '';
    
        if($is_editing) { 
            $content['general'] .= '<input type="hidden" name="wc_zip_force_edit" value="true" /> <input type="hidden" name="service_zipcode" value="'.$metadata['zipcode'].'" /> ';
        }
    
        $content['general'] .= '';
  
            $zipcode_field = 'service_zipcode';
            $zipcodeAttr = '';
    
            if($is_editing) {
                $zipcode_field = 'zipcode';
                $zipcodeAttr = array('disabled' => 'disabled');
            }
    
            $content['general'] .=  wc_zipcode_form_field($zipcode_field, array( 
                                    'type' => 'text', 
                                    'label' => __('Zip/Pin Code',WC_ZIP_V_TXT), 
                                    'return' => true, 
                                    'custom_attributes' => $zipcodeAttr,  ), $metadata['zipcode']);

            
            $content['general'] .= '<hr/>';
    
    
            $is_checked = $metadata['is_product'] == 'yes' ? 1 : 0 ;
            $content['general'] .=  wc_zipcode_form_field('meta[is_product]', array(
                                    'return' => true,
                                    'type' => 'checkbox' ,
                                    'label' => __("Apply to specific products only ?",WC_ZIP_V_TXT),
                                    'description' =>  __("(If checked, please select the products that this zip/pin code will apply to in the products tab)",WC_ZIP_V_TXT), ), $is_checked);
    
    
            $json_ids    = array();  
    if(!empty($metadata['product_data'])){
            foreach ( $metadata['product_data'] as $product_id ) {
                if(empty($product_id)){continue;}
				$product = wc_get_product( $product_id );
				$json_ids[ $product_id ] = wp_kses_post( $product->get_formatted_name() );
			}
        }
			
    
            $content['products'] =  wc_zipcode_form_field('for_products', array(
                                    'label' => __("Sellable Products",WC_ZIP_V_TXT), 
                                    'type' => 'hidden', 
                                    'return' => true, 
                                    'input_class' => array('wc-product-search'), 
                                    'custom_attributes' => array(
                                                            'multiple' => true ,
                                                            'data-action' => "woocommerce_json_search_products_and_variations",
                                                            'data-multiple' => "true", 
                                                            'data-selected' => esc_attr(json_encode($json_ids)),
                                                            )
                                                        ),implode(',',array_keys($json_ids))
                                    );
    
     
            $content['sp_set'] =  '';
    
            $content['sp_set'] .= wc_zipcode_form_field('meta[payment_gateway][]', array(
                                    'type' => 'select', 
                                    'label' => __("Allowed Payment Gateway * :",WC_ZIP_V_TXT),
                                    'input_class'       => array('wc-enhanced-select'),
                                    'return'            => true,
                                    'options'           => $gateways,
                                    'custom_attributes' => array( 'multiple' => true ,), 
                                    ), $metadata['payment_gateway'] );
    
            $content['sp_set'] .= wc_zipcode_form_field('meta[shipping_methods][]', array(
                                    'type' => 'select',    
                                    'label' => __("Allowed Shipping Methods  :",WC_ZIP_V_TXT),
                                    'force_empty_country' => true,
                                    'class'             => array(),
                                    'input_class'       => array('wc-enhanced-select'),
                                    'return'            => true,
                                    'options'           => $shippings,
                                    'custom_attributes' => array( 'multiple' => true ,),
                                    'value'             => null,
                                    ), $metadata['shipping_methods']);
    
    
           $content['others'] = '';
    
           $content['others'] .=  wc_zipcode_form_field('meta[country]', array(
                'type' => 'country',    
                'label' => __("Country :",WC_ZIP_V_TXT),
                'class'       => array(),
                'input_class' => array('wc-enhanced-select'),
                'return'      => true,
            ), $metadata['country'] );

           $content['others'] .=  wc_zipcode_form_field('meta[state]', array(
                'type' => 'text',  
                'label' => __("State",WC_ZIP_V_TXT),
                'class'  => array(),
                'return' => true,
                'force_empty_state' => true,
            ), $metadata['state'] );

            $content['others'] .= wc_zipcode_form_field('meta[city]', array(
                'type' => 'text',  
                'label' => __("City",WC_ZIP_V_TXT),
                'class' => array(),
                'input_class' => array(''),
                'return' => true,   
            ), $metadata['city']);
			
			 $content['others'] .= wc_zipcode_form_field('meta[area]', array(
                'type' => 'text',  
                'label' => __("Area",WC_ZIP_V_TXT),
                'class' => array(),
                'input_class' => array(''),
                'return' => true,   
            ), $metadata['area']);
    
            echo wc_zipcode_generate_tabs( array(
                "general" => __("General",WC_ZIP_V_TXT), 
                "products" => __("Products",WC_ZIP_V_TXT),
                "sp_set" => __("Shipping & Payments",WC_ZIP_V_TXT),
                "others" => __("Others",WC_ZIP_V_TXT)), $content);
?>
    
    
    <input type="hidden" value="wc_add_zipcode_admin" name="action"/>
       

</div>
<div class="submit_button">
    <?php
    $label = __("Add Pin/Zip/Postal Code",WC_ZIP_V_TXT);
    if($is_editing){$label = __("Update Pin/Zip/Postal Code",WC_ZIP_V_TXT);}?>
 <input id="add_zipcode_force" type="button" class="button button-primary right " value="<?php echo $label; ?>"/>
</div>

<script>
wc_zipcode_render_wootabs();
</script>
<script>
jQuery(document).ready(function(){ 
    //('.actDisplay').live('click', displayAction);
    jQuery(document.body).trigger( 'wc-enhanced-select-init' );
    
    jQuery("div.wczipcode_form_wrap, div#TB_ajaxContent").click(function(){
        jQuery("#select2-drop-mask").click();
    })
    
    jQuery("input#service_zipcode").blur(function(){
        wc_zip_add_btn_disable(true);
        jQuery("input#service_zipcode").removeClass("service_zipcode_error");
        var value = jQuery(this).val();
        wc_zip_code_validate_existing(value);
    });
    
    
    jQuery("#add_zipcode_force").click(function(){
        wc_zip_add_btn_disable(true);
        var form_data = jQuery("div#wczipcode_form_wrapper :input").serialize();
        jQuery.ajax({
            url : ajaxurl,
            data : form_data,
            method : "POST",

        }).done(function(res){
            jQuery("div.ajax_errors").html(res.data);
            wc_zip_add_btn_disable(false);
        })
    })
    
});
</script>

<style>
.service_zipcode_error{ 
    border-left: 3px solid red !important;
}

.wczipcode-tabs.wczipcode-tabs-left {
    margin: 0;
}
.wczipcode-tab-panel > div {
    margin-bottom: 15px;
    margin-top: 15px;
}
</style>