<br/><br/>
<table class="widefat striped ">
    <thead>
        <tr>
            <td><?php _e("ID ",WC_ZIP_V_TXT); ?></td>
            <td><?php _e("Name",WC_ZIP_V_TXT); ?></td>
            <td><?php _e("SKU",WC_ZIP_V_TXT); ?></td> 
        </tr>
    </thead>
    
    <tfoot>
        <tr>
            <td><?php _e("ID ",WC_ZIP_V_TXT); ?></td>
            <td><?php _e("Name",WC_ZIP_V_TXT); ?></td>
            <td><?php _e("SKU",WC_ZIP_V_TXT); ?></td> 
        </tr>
    </tfoot>
   <tbody>
    <?php
        foreach($product_data as $id){
            if(empty($id)){continue;}
            $editlink = '<a href="'.get_edit_post_link(null,null,$id).'">'.__("Edit Product",WC_ZIP_V_TXT).'</a>';
            $viewlink = ' | <a href="'.get_permalink($id).'">'.__("View Product",WC_ZIP_V_TXT).'</a>';
            
            $delete = admin_url("admin-ajax.php?action=wc_zipcode_remove_product&zipcode=".$code.'&product='.$id);
            $delete = ' | <span class="delete"> <a data-id="'.$id.'" href="javascript:void(0); " data-href="'.$delete.'">'.__("Remove",WC_ZIP_V_TXT).'</a> </span>';
            
            echo '<tr id="product'.$id.'">';
                echo '<td>#'.$id.'</td>';
                echo '<td>'.get_the_title($id).'
                    <div class="row-actions">'.$editlink.$viewlink.$delete.'</div>
                </td>';
                echo '<td>'.get_post_meta($id,'_sku',true).'</td>';
            echo '</tr>';
        }
    ?>
     </tbody>
</table>
<script>
jQuery(document).ready(function(){
    jQuery("span.delete a ").click(function(){
        var id = jQuery(this).attr("data-id");
        var th = jQuery(this);
        var aurl = th.attr("data-href");
        if(th.hasClass('inajaxing')){return;}
        th.toggleClass("inajaxing");
        th.parent().append("<span class='spinner is-active'></span>" );
        jQuery.ajax({
            url:aurl,
        }).done(function(res){
            th.parent().find('span.spinner').remove();
            if(res.success){
                console.log(1);
                jQuery('tr#product'+id).fadeOut();
            }
            th.toggleClass("inajaxing");
        })
    })
    
});
</script>

<br/> <br/>