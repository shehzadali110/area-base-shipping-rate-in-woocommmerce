<?php
/**
 * The admin-specific functionality of the plugin.
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/Admin
 * @since 3.0
 */
if ( ! defined( 'WPINC' ) ) { die; }

class woocommerce_zipcode_validation_frontend_Ajax_Handler {
    
    public function __construct() {
        add_filter( 'woocommerce_available_payment_gateways',array($this,'allow_block_gateway'),10);
        add_filter( 'woocommerce_shipping_methods',  array($this,'allow_block_shipping'),10);
        
        add_action("woocommerce_checkout_update_order_review",array($this,'check_pincode'));
    }
    //WC()->session->reload_checkout
    
    
    public function check_cod_status($code){
        $status_cod_check = wc_zipcode_val_option('enable_cod_verification');
        $selected_gateway = $this->get_metadata($code,'payment_gateway');
        if(!empty($selected_gateway)){
            if($status_cod_check == 'on'){
                if(!in_array('cod',$selected_gateway)){
                    $error_msg = wc_zipcode_val_option('cod_error_msg');
                    $error_msg = str_replace('[zip_pin_code]',$code,$error_msg);
                    wc_add_notice($error_msg,'error');
                }
            }
        } 
    }
    
    
    public function check_product_validation($code){
        

           $is_check = wc_zipcode_val_option('enable_zippincode_product_verification',false);
        $status = wc_get_zipcode($code,'is_product',true);
        $size = WC()->cart->get_cart_contents_count(); 
        if($status == 'yes'){
            $pids = wc_get_zipcode($code,'product_ids',true);
            
            if(!empty($pids)){
                $items = WC()->cart->get_cart();  
                
                foreach($items as $i => $v){ 
                    
                    if(! in_array($v['product_id'],$pids)){
                        WC()->cart->remove_cart_item($i);
                        $msg = wc_zipcode_val_option('zippincode_product_verification_msg');
                        $msg =str_replace(array('[zip_pin_code]','[product_name]'),array($code,get_the_title($v['product_id'])),$msg);
                        wc_add_notice($msg,'error');
                    } 
                }
                
                $size = WC()->cart->get_cart_contents_count(); 
                if(! $size){
                    WC()->session->reload_checkout = true;
                }
            }
        }
        return $size;
    }
    
    
    public function check_pincode(){
        $status = $this->check_if_wc_ajax();
        
        if($status){
            $code = null;
            if(isset($status['ship_to_different_address'])){
                $code = $_REQUEST['s_postcode'];
            } else {
                $code = $_REQUEST['postcode'];
            }
            
            $pin = $this->get_metadata($code,'zipcode');
            
            if($pin){
                $cart_size = $this->check_product_validation($code);
                if($cart_size >= 1){
                    $this->check_cod_status($code);
                }
             } else { 
                $status_check = wc_zipcode_val_option('enable_zippincode_verification');
                if($status_check == 'on'){
                    $error_msg = wc_zipcode_val_option('zippincode_verification_msg');
                    $error_msg = str_replace('[zip_pin_code]',$code,$error_msg);
                    wc_add_notice($error_msg,'error');
                } 
            }
        }
    }
    
    public function check_if_wc_ajax(){
        $args = false;
        if(isset($_REQUEST['wc-ajax'])){
            if(isset($_REQUEST['post_data'])){
                $args = wp_parse_args($_REQUEST['post_data']);
            }
        }
        
        return $args;
    }
    
    
    public function get_metadata($code,$type){
        $exists = metadata_exists('wczipcode',$code,'zipcode_data' ) ;
        if($exists){
            $types = wc_get_zipcode($code, 'zipcode_data',true);
            $types = isset($types[$type]) ? $types[$type] : array(); 
            return $types;
        }
        
        return false;
    }
    
    
    public function allow_block_gateway($gateways){
        $gateway = $gateways;
        $status = $this->check_if_wc_ajax();
        if($status){
            $code = null;
            if(isset($status['ship_to_different_address'])){
                $code = $_REQUEST['s_postcode'];
            } else {
                $code = $_REQUEST['postcode'];
            } 
            
            $selected_gateway = $this->get_metadata($code,'payment_gateway');
            if($selected_gateway){
                $gateways_return = array(); 
                foreach($selected_gateway as $type){
                    if(!isset($gateways[$type])){continue;}
                    $gateways_return[$type] = $gateways[$type];
                } 
                $gateway = $gateways_return;
            } else {
                if(empty($selected_gateway)){
                    $gateway = $gateways;
                } else{
                    $status_check = wc_zipcode_val_option('enable_zippincode_verification');
                    if($status_check == 'on'){
                        $gateway =array();
                    }
                }
            }
            
        }
        return $gateway; 
    }
    
    
    public function allow_block_shipping($shippings){
        $shipping = $shippings; 
        $status = $this->check_if_wc_ajax();
        
        if($status){
            $code = null;
            if(isset($status['ship_to_different_address'])){
                $code = $_REQUEST['s_postcode'];
            } else {
                $code = $_REQUEST['postcode'];
            } 
            
            $selected_gateway = $this->get_metadata($code,'shipping_methods');  
            if(!empty($selected_gateway)){
                $gateways_return = array();
                foreach($selected_gateway as $type){ 
                    if(!isset($shippings[$type])){continue;}
                    $gateways_return[$type] = $shippings[$type];
                }

                $shipping = $gateways_return; 
            } else {
                if(empty($selected_gateway)){
                    //$shipping = $shippings;
                } else{
                    $status_check = wc_zipcode_val_option('enable_zippincode_verification');
                    if($status_check == 'on'){
                        $shipping =array();
                    }
                }
            }
        }
        
        return $shipping; 
    }
    
    
    
    public function check_frontend_zipcode(){
        if(isset($_REQUEST['zipcode'])){
            $code = $_REQUEST['zipcode'];
            $exists = metadata_exists('wczipcode',$code,'zipcode_data' ) ;
            if($exists){
                $types = wc_get_zipcode($code, 'zipcode_data',true);
                
                $return = wc_zipcode_get_service_methods();
                foreach($return as $id => $type){
                    if(in_array($id,$types)){
                        $return[$id] = true;
                    } else {
                        $return[$id] = false;
                    }
                }
                
                wp_send_json_success($return);
            } else {
                wp_send_json_error();
            }
            
        } else {
            wp_send_json_error();
        }
        
        wp_die(); 
    }
}