<?php 
/**
 * Plugin Main File
 *
 * @link https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @package WC_ZIP_CODE_VALIDATION
 * @subpackage WC_ZIP_CODE_VALIDATION/core
 * @since 1.0
 */
if ( ! defined( 'WPINC' ) ) { die; }
 
class woocommerce_zipcode_validation {
	public $version = '1.1';
	public $plugin_vars = array();
	
	protected static $_instance = null; # Required Plugin Class Instance
    public static $functions = null; # Required Plugin Class Instance
	public static $admin = null;     # Required Plugin Class Instance
	public static $settings = null;  # Required Plugin Class Instance
    public static $query = null;  # Required Plugin Class Instance

    /**
     * Creates or returns an instance of this class.
     */
    public static function get_instance() {
        if ( null == self::$_instance ) {
            self::$_instance = new self;
        }
        return self::$_instance;
    }
    
    /**
     * Class Constructor
     */
    public function __construct() {
        $this->define_constant();
        $this->load_required_files();
        $this->init_class();
        add_action('plugins_loaded', array( $this, 'after_plugins_loaded' ));
        add_filter('load_textdomain_mofile',  array( $this, 'load_plugin_mo_files' ), 10, 2);
    }
	
	/**
	 * Throw error on object clone.
	 *
	 * Cloning instances of the class is forbidden.
	 *
	 * @since 1.0
	 * @return void
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, __( 'Cloning instances of the class is forbidden.', WC_ZIP_V_TXT), WC_ZIP_V_V );
	}	

	/**
	 * Disable unserializing of the class
	 *
	 * Unserializing instances of the class is forbidden.
	 *
	 * @since 1.0
	 * @return void
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, __( 'Unserializing instances of the class is forbidden.',WC_ZIP_V_TXT), WC_ZIP_V_V);
	}

    /**
     * Loads Required Plugins For Plugin
     */
    private function load_required_files(){
       $this->load_files(WC_ZIP_V_SETTINGS.'class-wp-*.php');
       $this->load_files(WC_ZIP_V_INC.'class-*.php');
	   
        
       if(wc_zipcode_val_is_request('admin')){
           $this->load_files(WC_ZIP_V_ADMIN.'class-*.php');
       } 

        do_action('wc_zipcode_val_before_addons_load');
		$this->load_addons();
    }
    
	public function load_addons(){ 
		$addons = wc_zipcode_val_get_active_addons();
		if(!empty($addons)){
			foreach($addons as $addon){
				if(apply_filters('wc_zipcode_val_load_addon',true,$addon)){
					do_action('wc_zipcode_val_before_'.$addon.'_addon_load');
					$this->load_addon($addon);
					do_action('wc_zipcode_val_after_'.$addon.'_addon_load');
				}
			}
		}
	}
    
	public function load_addon($file){
		if(file_exists(PLUGIN_ADDON.$file)){
			$this->load_files(PLUGIN_ADDON.$file);
		} else if(file_exists($file = apply_filters('wc_zipcode_val_addon_file_location',$file))) {
			$this->load_files($file);
		} else {
            if(has_action('wc_zipcode_val_addon_'.$file.'_load')){
                do_action('wc_zipcode_val_addon_'.$file.'_load');    
            } else {
                
                wc_zipcode_val_deactivate_addon($file);
            }
			
		}
	}
   
    /**
     * Inits loaded Class
     */
    private function init_class(){
        do_action('wc_zipcode_val_before_init');
        new woocommerce_zipcode_validation_frontend_Ajax_Handler;
        self::$query = new woocommerce_zipcode_validation_query; 
		self::$settings = new woocommerce_zipcode_validation_Settings_Framework; 
        new woocommerce_zipcode_validation_Functions;
        if(wc_zipcode_val_is_request('admin')){
            self::$admin = new woocommerce_zipcode_validation_Admin;
        }
        do_action('wc_zipcode_val_after_init');
    }
    
	# Returns Plugin's Functions Instance
	public function func(){
		return self::$functions;
	}
	
    public function query(){
        return self::$query;
    }
    
	# Returns Plugin's Settings Instance
	public function settings(){
		return self::$settings;
	}
	
	# Returns Plugin's Admin Instance
	public function admin(){
		return self::$admin;
	}
    
    /**
     * Loads Files Based On Give Path & regex
     */
    protected function load_files($path,$type = 'require'){
        foreach( glob( $path ) as $files ){
            if($type == 'require'){ require_once( $files ); } 
			else if($type == 'include'){ include_once( $files ); }
        } 
    }
    
    /**
     * Set Plugin Text Domain
     */
    public function after_plugins_loaded(){
        load_plugin_textdomain(WC_ZIP_V_TXT, false, WC_ZIP_V_LANGUAGE_PATH );
    }
    
    /**
     * load translated mo file based on wp settings
     */
    public function load_plugin_mo_files($mofile, $domain) {
        if (WC_ZIP_V_TXT === $domain)
            return WC_ZIP_V_LANGUAGE_PATH.'/'.get_locale().'.mo';

        return $mofile;
    }
    
    /**
     * Define Required Constant
     */
    private function define_constant(){
        $this->define('WC_ZIP_V_NAME', 'WooCommerce AreaBase ShippingRate'); # Plugin Name
        $this->define('WC_ZIP_V_SLUG', 'wooCommerce-area-base-shipping-rate'); # Plugin Slug
        $this->define('WC_ZIP_V_TXT',  'wooCommerce-area-base-shipping-rate'); #plugin lang Domain
		$this->define('WC_ZIP_V_DB', 'wc_zipcode_val_');
		$this->define('WC_ZIP_V_V',$this->version); # Plugin Version
		
		$this->define('WC_ZIP_V_LANGUAGE_PATH',WC_ZIP_V_PATH.'languages'); # Plugin Language Folder
		$this->define('WC_ZIP_V_ADMIN',WC_ZIP_V_INC.'admin/'); # Plugin Admin Folder
		$this->define('WC_ZIP_V_SETTINGS',WC_ZIP_V_ADMIN.'settings_framework/'); # Plugin Settings Folder
	   
		$this->define('WC_ZIP_V_URL',plugins_url('', __FILE__ ).'/');  # Plugin URL
		$this->define('WC_ZIP_V_CSS',WC_ZIP_V_URL.'includes/css/'); # Plugin CSS URL
		$this->define('WC_ZIP_V_IMG',WC_ZIP_V_URL.'includes/img/'); # Plugin IMG URL
		$this->define('WC_ZIP_V_JS',WC_ZIP_V_URL.'includes/js/'); # Plugin JS URL 
    }
	
    /**
	 * Define constant if not already set
	 * @param  string $name
	 * @param  string|bool $value
	 */
    protected function define($key,$value){
        if(!defined($key)){
            define($key,$value);
        }
    }
    
}