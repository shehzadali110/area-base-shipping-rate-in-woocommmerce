<?php 
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * @since             1.0
 * @package           WooCommerce AreaBase ShippingRate
 *
 * @wordpress-plugin
 * Plugin Name:       WooCommerce Area Base Shipping Rate
 * Plugin URI:        https://github.com/shehzadali110/area-base-shipping-rate-in-woocommmerce
 * Description:       Manage Payment , Shipping And COD Based on Zip / Pin / Postal Code / Area Base
 * Version:           1.2
 * Author:            Varun Sridharan
 * Author URI:        http://varunsridharan.in
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wooCommerce-area-base-shipping-rate
 * Domain Path:       /languages
 */

if ( ! defined( 'WPINC' ) ) { die; }
 
define('WC_ZIP_V_FILE',plugin_basename( __FILE__ ));
define('WC_ZIP_V_PATH',plugin_dir_path( __FILE__ )); # Plugin DIR
define('WC_ZIP_V_INC',WC_ZIP_V_PATH.'includes/'); # Plugin INC Folder
define('WC_ZIP_V_DEPEN','woocommerce/woocommerce.php');

register_activation_hook( __FILE__, 'wc_zipcode_val_activate_plugin' );
register_deactivation_hook( __FILE__, 'wc_zipcode_val_deactivate_plugin' );
register_deactivation_hook( WC_ZIP_V_DEPEN, 'wc_zipcode_val_dependency_deactivate' );



/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-plugin-name-activator.php
 */
function wc_zipcode_val_activate_plugin() {
	require_once(WC_ZIP_V_INC.'helpers/class-activator.php');
	woocommerce_zipcode_validation_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-plugin-name-deactivator.php
 */
function wc_zipcode_val_deactivate_plugin() {
	require_once(WC_ZIP_V_INC.'helpers/class-deactivator.php');
	woocommerce_zipcode_validation_Deactivator::deactivate();
}


/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-plugin-name-deactivator.php
 */
function wc_zipcode_val_dependency_deactivate() {
	require_once(WC_ZIP_V_INC.'helpers/class-deactivator.php');
	woocommerce_zipcode_validation_Deactivator::dependency_deactivate();
}



require_once(WC_ZIP_V_INC.'functions.php');
require_once(WC_ZIP_V_PATH.'bootstrap.php');

if(!function_exists('woocommerce_zipcode_validation')){
    function woocommerce_zipcode_validation(){
        return woocommerce_zipcode_validation::get_instance();
    }
}
woocommerce_zipcode_validation();